"""Generate the Xcode project with the pinned Google Cast package; safe to run on Windows or macOS."""
import json
import pathlib
import plistlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = ROOT / 'LumaCast'
PROJECT = ROOT / 'LumaCast.xcodeproj'
# Verify the native relay on the macOS builder before spending time on an iPhone archive.
import platform
import subprocess
import tempfile
if platform.system() == 'Darwin':
    check = str(pathlib.Path(tempfile.gettempdir()) / 'luma-relay-checks')
    subprocess.run(['swiftc', '-swift-version', '5', 'LumaCast/CastDiagnostics.swift', 'LumaCast/MediaRules.swift', 'LumaCast/MediaRelay.swift', 'Tests/RelayChecks.swift', '-o', check], cwd=ROOT, check=True)
    subprocess.run([check], cwd=ROOT, check=True, timeout=60)
    probe_check = str(pathlib.Path(tempfile.gettempdir()) / 'luma-direct-checks')
    subprocess.run(['swiftc', '-swift-version', '5', 'LumaCast/MediaRules.swift', 'LumaCast/DirectMediaProbe.swift', 'Tests/DirectChecks.swift', '-o', probe_check], cwd=ROOT, check=True)
    subprocess.run([probe_check], cwd=ROOT, check=True, timeout=60)
    remote_check = str(pathlib.Path(tempfile.gettempdir()) / 'luma-remote-checks')
    subprocess.run(['swiftc', '-swift-version', '5', 'LumaCast/TVRemoteRules.swift', 'LumaCast/TVRemoteIdentity.swift', 'Tests/RemoteChecks.swift', '-o', remote_check], cwd=ROOT, check=True)
    subprocess.run([remote_check], cwd=ROOT, check=True, timeout=30)

objects = {}
sequence = 0

def add(kind, **values):
    global sequence
    sequence += 1
    key = f'{sequence:024X}'
    objects[key] = dict(isa=kind, **values)
    return key

def configurations(settings):
    return add('XCConfigurationList', buildConfigurations=[
        add('XCBuildConfiguration', name='Debug', buildSettings={**settings, 'SWIFT_OPTIMIZATION_LEVEL': '-Onone', 'DEBUG_INFORMATION_FORMAT': 'dwarf'}),
        add('XCBuildConfiguration', name='Release', buildSettings={**settings, 'SWIFT_OPTIMIZATION_LEVEL': '-O', 'DEBUG_INFORMATION_FORMAT': 'dwarf-with-dsym'})
    ], defaultConfigurationIsVisible=0, defaultConfigurationName='Release')

source_builds, resource_builds, refs = [], [], []
for source in sorted(APP.glob('*.swift')):
    ref = add('PBXFileReference', lastKnownFileType='sourcecode.swift', path=source.name, sourceTree='<group>')
    refs.append(ref)
    source_builds.append(add('PBXBuildFile', fileRef=ref))
resource_refs = []
for resource in sorted((APP / 'Resources').glob('*')):
    if not resource.is_file():
        continue
    ref = add('PBXFileReference', lastKnownFileType={'.json':'text.json','.js':'sourcecode.javascript','.mp4':'video.mp4','.txt':'text'}.get(resource.suffix,'file'), path=resource.name, sourceTree='<group>')
    resource_refs.append(ref)
    resource_builds.append(add('PBXBuildFile', fileRef=ref))
refs.append(add('PBXGroup', path='Resources', sourceTree='<group>', children=resource_refs))
assets = add('PBXFileReference', lastKnownFileType='folder.assetcatalog', path='Assets.xcassets', sourceTree='<group>')
refs.append(assets)
resource_builds.append(add('PBXBuildFile', fileRef=assets))
refs.append(add('PBXFileReference', lastKnownFileType='text.plist.xml', path='Info.plist', sourceTree='<group>'))
app_group = add('PBXGroup', path='LumaCast', children=refs, sourceTree='<group>')
product = add('PBXFileReference', explicitFileType='wrapper.application', includeInIndex=0, path='LumaCast.app', sourceTree='BUILT_PRODUCTS_DIR')
products = add('PBXGroup', name='Products', children=[product], sourceTree='<group>')
root_group = add('PBXGroup', children=[app_group, products], sourceTree='<group>')
sources = add('PBXSourcesBuildPhase', buildActionMask=2147483647, files=source_builds, runOnlyForDeploymentPostprocessing=0)
cast_package = add('XCRemoteSwiftPackageReference', repositoryURL='https://github.com/googlecast/google-cast-ios-sdk', requirement={'kind': 'exactVersion', 'version': '4.8.6'})
cast_product = add('XCSwiftPackageProductDependency', package=cast_package, productName='GoogleCastDynamic')
cast_link = add('PBXBuildFile', productRef=cast_product)
remote_package = add('XCLocalSwiftPackageReference', relativePath='Vendor/AndroidTVRemoteControl')
remote_product = add('XCSwiftPackageProductDependency', package=remote_package, productName='AndroidTVRemoteControl')
remote_link = add('PBXBuildFile', productRef=remote_product)
frameworks = add('PBXFrameworksBuildPhase', buildActionMask=2147483647, files=[cast_link, remote_link], runOnlyForDeploymentPostprocessing=0)
resources = add('PBXResourcesBuildPhase', buildActionMask=2147483647, files=resource_builds, runOnlyForDeploymentPostprocessing=0)
settings = {
    'PRODUCT_NAME': 'LumaCast', 'PRODUCT_BUNDLE_IDENTIFIER': 'dev.kayle.lumacast',
    'SWIFT_VERSION': '5.0', 'SWIFT_STRICT_CONCURRENCY': 'minimal',
    'IPHONEOS_DEPLOYMENT_TARGET': '17.0', 'SDKROOT': 'iphoneos',
    'TARGETED_DEVICE_FAMILY': '1,2', 'INFOPLIST_FILE': 'LumaCast/Info.plist',
    'CODE_SIGN_STYLE': 'Automatic', 'CURRENT_PROJECT_VERSION': '15', 'MARKETING_VERSION': '0.4.0',
    'ASSETCATALOG_COMPILER_APPICON_NAME': 'AppIcon', 'ENABLE_USER_SCRIPT_SANDBOXING': 'YES',
    'SUPPORTED_PLATFORMS': 'iphoneos iphonesimulator', 'SUPPORTS_MACCATALYST': 'NO',
    'LD_RUNPATH_SEARCH_PATHS': ['$(inherited)', '@executable_path/Frameworks'],
    'GENERATE_INFOPLIST_FILE': 'NO'
}
target = add('PBXNativeTarget', buildConfigurationList=configurations(settings), buildPhases=[sources, frameworks, resources], buildRules=[], dependencies=[], name='LumaCast', productName='LumaCast', productReference=product, productType='com.apple.product-type.application', packageProductDependencies=[cast_product, remote_product])
project = add('PBXProject', attributes={'LastUpgradeCheck': '1600', 'BuildIndependentTargetsInParallel': 'YES'}, buildConfigurationList=configurations({'CLANG_ENABLE_MODULES': 'YES', 'CLANG_ENABLE_OBJC_ARC': 'YES', 'ENABLE_STRICT_OBJC_MSGSEND': 'YES'}), compatibilityVersion='Xcode 14.0', developmentRegion='en', knownRegions=['en', 'Base'], mainGroup=root_group, productRefGroup=products, projectDirPath='', projectRoot='', targets=[target], packageReferences=[cast_package, remote_package])

def encode(value, level=0):
    if isinstance(value, dict):
        return '{\n' + ''.join('\t'*(level+1) + json.dumps(str(k)) + ' = ' + encode(v,level+1) + ';\n' for k,v in value.items()) + '\t'*level + '}'
    if isinstance(value, list):
        return '(\n' + ''.join('\t'*(level+1)+encode(v,level+1)+',\n' for v in value) + '\t'*level + ')'
    return str(value) if isinstance(value, int) else json.dumps(value)

PROJECT.mkdir(exist_ok=True)
(PROJECT / 'project.pbxproj').write_text('// !$*UTF8*$!\n' + encode(dict(archiveVersion=1, classes={}, objectVersion=56, objects=objects, rootObject=project)) + '\n', encoding='utf-8')
scheme = PROJECT / 'xcshareddata' / 'xcschemes'
scheme.mkdir(parents=True, exist_ok=True)
(scheme / 'LumaCast.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
 <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="LumaCast.app" BlueprintName="LumaCast" ReferencedContainer="container:LumaCast.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
 <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="LumaCast.app" BlueprintName="LumaCast" ReferencedContainer="container:LumaCast.xcodeproj"/></BuildableProductRunnable></LaunchAction>
 <AnalyzeAction buildConfiguration="Debug"/>
 <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''',encoding='utf-8')
info = {
    'CFBundleDevelopmentRegion': 'en', 'CFBundleDisplayName': 'Luma Cast', 'CFBundleExecutable': '$(EXECUTABLE_NAME)',
    'CFBundleIdentifier': '$(PRODUCT_BUNDLE_IDENTIFIER)', 'CFBundleInfoDictionaryVersion': '6.0', 'CFBundleName': '$(PRODUCT_NAME)',
    'CFBundlePackageType': 'APPL', 'CFBundleShortVersionString': '$(MARKETING_VERSION)', 'CFBundleVersion': '$(CURRENT_PROJECT_VERSION)',
    'LSRequiresIPhoneOS': True, 'UILaunchScreen': {},
    'UISupportedInterfaceOrientations': ['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
    'UISupportedInterfaceOrientations~ipad': ['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
    'NSLocalNetworkUsageDescription': 'Cast media to and control your TV over your home Wi-Fi network.',
    'NSBonjourServices': ['_googlecast._tcp', '_CC1AD845._googlecast._tcp'],
    'NSAppTransportSecurity': {'NSAllowsArbitraryLoadsInWebContent': True,'NSAllowsArbitraryLoadsForMedia': True,'NSAllowsLocalNetworking': True},
    'ITSAppUsesNonExemptEncryption': False
}
with (APP / 'Info.plist').open('wb') as output: plistlib.dump(info, output)
print('Generated', PROJECT)
