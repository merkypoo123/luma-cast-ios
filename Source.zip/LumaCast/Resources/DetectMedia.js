(() => {
  'use strict';
  const seen = new Set();
  const excluded = new Set();
  const inspected = new Set();
  const MAX_PLAYLIST = 4 * 1024 * 1024;
  const probed = new Set();
  function post(body) {
    try { body.frameURL = typeof location !== 'undefined' ? location.href : document.baseURI; window.webkit.messageHandlers.stream.postMessage(body); } catch {}
  }
  function absolute(value, base) {
    try {
      const u = new URL(value, base);
      return ['http:', 'https:'].includes(u.protocol) && !u.username && !u.password && u.href.length <= 16384 ? u.href : null;
    } catch { return null; }
  }
  function exclude(value, base) {
    const url = absolute(value, base);
    if (!url || excluded.has(url)) return;
    excluded.add(url);
    post({event: 'exclude', url});
  }
  function inspectPlaylist(value, text) {
    if (typeof text !== 'string' || text.length > MAX_PLAYLIST || !text.trimStart().startsWith('#EXTM3U')) return;
    const blob = typeof value === 'string' && /^blob:https?:/.test(value);
    const url = blob ? value : absolute(value, document.baseURI);
    const base = blob ? document.baseURI : url;
    if (!url || inspected.has(url)) return;
    inspected.add(url);
    const lines = text.split(/\r?\n/).map(x => x.trim());
    const master = lines.some(x => x.startsWith('#EXT-X-STREAM-INF:'));
    // A media playlist's entries and MAP are fragments, even when an opaque /api URL looks like MP4.
    for (const line of lines) {
      if (line.startsWith('#EXT-X-MAP:')) {
        const uri = /(?:^|,)URI="([^"]+)"/.exec(line.slice(line.indexOf(':') + 1));
        if (uri) exclude(uri[1], base);
      }
      if (!line || line.startsWith('#')) continue;
      // Keep the master instead of a video-only variant that loses its separate audio group.
      exclude(line, base);
    }
    if (master) {
      for (const line of lines.filter(x => x.startsWith('#EXT-X-MEDIA:'))) {
        const uri = /(?:^|,)URI="([^"]+)"/.exec(line.slice(line.indexOf(':') + 1));
        if (uri) exclude(uri[1], base);
      }
    }
    post({event: 'playlist', url, type: 'application/vnd.apple.mpegurl', title: String(document.title || 'Web video').slice(0, 200), role: master ? 'master' : 'media', playlist: text, baseURL: base});
  }
  async function inspectResponse(response) {
    if (!response.clone || !response.url) return;
    const type = response.headers.get('Content-Type') || '';
    const length = Number(response.headers.get('Content-Length') || 0);
    if (length > MAX_PLAYLIST) return;
    const copy = response.clone();
    // Read a bounded clone, never the response consumed by the website player.
    if (!copy.body || !copy.body.getReader) {
      if (/mpegurl/i.test(type) && length > 0 && copy.text) inspectPlaylist(response.url, await copy.text());
      return;
    }
    const reader = copy.body.getReader();
    let size = 0, text = '';
    const decoder = new TextDecoder();
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        size += chunk.value.byteLength;
        if (size > MAX_PLAYLIST) return;
        text += decoder.decode(chunk.value, {stream: true});
        if (text.trimStart().length >= 7 && !text.trimStart().startsWith('#EXTM3U')) return;
      }
      inspectPlaylist(response.url, text + decoder.decode());
    } finally { reader.cancel().catch(() => {}); }
  }
  function candidate(value, type = '') {
    try {
      const url = new URL(value, document.baseURI);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.href.length > 16384) return null;
      const path = url.pathname.toLowerCase();
      const name = path.split('/').pop();
      if (/\.(ts|m4s|cmfa|cmfv|aac)$/.test(path) || /^(init|chunk|segment|frag)[-_0-9.]/.test(name)) return null;
      if (/^\d+$/.test(url.searchParams.get('seg') || '')) return null;
      if (!/\.(m3u8|mpd|webm|mp4|mov|mp3|m4a)$/.test(path) && !/mpegurl|dash\+xml|video\/webm|video\/mp4|video\/quicktime|audio\/(mpeg|mp4)/i.test(type)) return null;
      return url.href;
    } catch { return null; }
  }
  function inspectNativePlaylist(url, type) {
    if ((!/\.m3u8(?:[?#]|$)/i.test(url) && !/mpegurl/i.test(type)) || probed.has(url) || probed.size >= 20 || !originalFetch) return;
    probed.add(url);
    // Native Safari HLS requests do not pass through the JS fetch/XHR hooks.
    // Read a bounded playlist copy in this frame's browser context, never the movie bytes.
    originalFetch.call(window, url, {credentials: 'same-origin'}).then(async response => { try { await inspectResponse(response); } finally { if (response.body) response.body.cancel().catch(() => {}); } }).catch(() => {});
  }
  function report(value, type = '') {
    const url = candidate(value, type);
    if (!url || excluded.has(url) || seen.has(url) || seen.size >= 150) return;
    seen.add(url);
    post({url, type: String(type), title: String(document.title || 'Web video').slice(0, 200)});
    inspectNativePlaylist(url, type);
  }
  function scan() {
    document.querySelectorAll('video,audio,source').forEach(node => {
      if (node.currentSrc) report(node.currentSrc, node.type || '');
      if (node.src) report(node.src, node.type || '');
    });
    performance.getEntriesByType('resource').forEach(entry => report(entry.name));
  }
  window.__lumaScan = scan;
  // Some players manufacture the only full audio/video playlist in memory.
  // Capture its text while it exists; never treat a MediaSource blob as a playlist.
  const originalCreate = URL.createObjectURL;
  if (originalCreate) URL.createObjectURL = function (...args) {
    const url = originalCreate.apply(this, args);
    const blob = args[0];
    if (blob && typeof blob.text === 'function' && blob.size <= MAX_PLAYLIST) {
      blob.text().then(text => inspectPlaylist(url, text)).catch(() => {});
    }
    return url;
  };
  // Inspect bounded response copies; preserve the website player's original response.
  const originalFetch = window.fetch;
  if (originalFetch) window.fetch = function (...args) {
    return originalFetch.apply(this, args).then(response => {
      report(response.url, response.headers.get('Content-Type') || '');
      inspectResponse(response).catch(() => {});
      return response;
    });
  };
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', () => {
      try {
        report(this.responseURL, this.getResponseHeader('Content-Type') || '');
        if (!this.responseType || this.responseType === 'text') inspectPlaylist(this.responseURL, this.responseText);
        else if (this.responseType === 'blob' && this.response && this.response.size <= MAX_PLAYLIST) this.response.text().then(text => inspectPlaylist(this.responseURL, text)).catch(() => {});
        else if (this.responseType === 'arraybuffer' && this.response && this.response.byteLength <= MAX_PLAYLIST) inspectPlaylist(this.responseURL, new TextDecoder().decode(this.response));
      } catch {}
    }, {once: true});
    return originalSend.apply(this, args);
  };
  try {
    new PerformanceObserver(list => list.getEntries().forEach(entry => report(entry.name))).observe({type: 'resource', buffered: true});
  } catch {}
  document.addEventListener('loadedmetadata', scan, true);
  document.addEventListener('play', scan, true);
  document.addEventListener('DOMContentLoaded', () => {
    scan();
    let pending = false;
    new MutationObserver(() => {
      if (!pending) {
        pending = true;
        setTimeout(() => { pending = false; scan(); }, 500);
      }
    }).observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ['src']});
  }, {once: true});
})();
