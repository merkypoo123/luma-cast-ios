(() => {
  'use strict';
  const seen = new Set();
  function candidate(value, type = '') {
    try {
      const url = new URL(value, document.baseURI);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.href.length > 16384) return null;
      const path = url.pathname.toLowerCase();
      const name = path.split('/').pop();
      if (/\.(ts|m4s|cmfa|cmfv|aac)$/.test(path) || /^(init|chunk|segment|frag)[-_0-9.]/.test(name)) return null;
      if (/^\d+$/.test(url.searchParams.get('seg') || '')) return null;
      if (!/\.(m3u8|mpd|webm|mp4|mov|mp3|m4a)$/.test(path) && !/mpegurl|dash\+xml|video\/webm|video\/mp4|video\/quicktime|audio\/(mpeg|mp4)/i.test(type)) return null;
      return url.href;
    } catch { return null; }
  }
  function report(value, type = '') {
    const url = candidate(value, type);
    if (!url || seen.has(url) || seen.size >= 150) return;
    seen.add(url);
    try { window.webkit.messageHandlers.stream.postMessage({url, type: String(type), title: String(document.title || 'Web video').slice(0, 200)}); } catch {}
  }
  function scan() {
    document.querySelectorAll('video,audio,source').forEach(node => {
      if (node.currentSrc) report(node.currentSrc, node.type || '');
      if (node.src) report(node.src, node.type || '');
    });
    performance.getEntriesByType('resource').forEach(entry => report(entry.name));
  }
  window.__lumaScan = scan;
  // Observe network responses without reading or changing response bodies.
  const originalFetch = window.fetch;
  if (originalFetch) window.fetch = function (...args) {
    return originalFetch.apply(this, args).then(response => {
      report(response.url, response.headers.get('Content-Type') || '');
      return response;
    });
  };
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', () => {
      try { report(this.responseURL, this.getResponseHeader('Content-Type') || ''); } catch {}
    }, {once: true});
    return originalSend.apply(this, args);
  };
  try {
    new PerformanceObserver(list => list.getEntries().forEach(entry => report(entry.name))).observe({type: 'resource', buffered: true});
  } catch {}
  document.addEventListener('loadedmetadata', scan, true);
  document.addEventListener('play', scan, true);
  document.addEventListener('DOMContentLoaded', () => {
    scan();
    let pending = false;
    new MutationObserver(() => {
      if (!pending) {
        pending = true;
        setTimeout(() => { pending = false; scan(); }, 500);
      }
    }).observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ['src']});
  }, {once: true});
})();
