import SwiftUI

@MainActor struct TVRemoteView: View {
    @ObservedObject var model: TVRemoteModel
    let onHome: () -> Void
    @Environment(\.scenePhase) private var scenePhase
    @State private var connectionSheet = false
    @State private var keyboardSheet = false
    @State private var numberSheet = false
    @State private var pairingCode = ""
    @State private var typedText = ""
    private let ink = Color(white:0.13)

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            ScrollView {
                VStack(spacing:18) {
                    header
                    if !model.connected {
                        VStack(spacing:7) {
                            Text(model.status).font(.footnote).foregroundStyle(.gray).multilineTextAlignment(.center)
                            Button(model.busy ? "Connecting…" : "Connect or pair TV") { connectionSheet = true }
                                .font(.subheadline.weight(.semibold)).foregroundStyle(.indigo)
                        }.padding(.horizontal)
                    }
                    VStack(spacing:18) {
                        dpad
                        navigationKeys
                        volumeKeys
                        utilityKeys
                        appShortcuts
                    }.disabled(!model.connected).opacity(model.connected ? 1 : 0.48)
                    Button(action:onHome) {
                        Label("Home",systemImage:"house.fill").font(.subheadline.weight(.semibold))
                            .foregroundStyle(ink).padding(.horizontal,30).padding(.vertical,13)
                            .background(Color(white:0.94),in:Capsule())
                    }.accessibilityLabel("Return to Luma Cast home")
                }.padding(.horizontal,24).padding(.top,8).padding(.bottom,18)
                    .frame(maxWidth:470).frame(maxWidth:.infinity)
            }
        }
        .toolbar(.hidden,for:.tabBar)
        .onAppear { model.connectIfPaired() }
        .onChange(of:model.connected) { connected in if connected { connectionSheet = false; pairingCode = "" } }
        .onChange(of:scenePhase) { phase in if phase == .active { model.connectIfPaired() } else if phase == .background { model.disconnect() } }
        .sheet(isPresented:$connectionSheet) { connectionPanel }
        .sheet(isPresented:$keyboardSheet) { keyboardPanel }
        .sheet(isPresented:$numberSheet) { numericPanel }
    }
    private var header: some View {
        HStack(spacing:14) {
            Button { model.press(26) } label: { Image(systemName:"power").font(.title3).foregroundStyle(.red).frame(width:40,height:44) }
                .disabled(!model.connected).accessibilityLabel("TV power")
            Button { connectionSheet = true } label: {
                HStack(spacing:12) {
                    Image(systemName:"tv").font(.subheadline)
                    Text(model.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Circle().fill(model.connected ? Color.green : Color.gray).frame(width:6,height:6)
                }.foregroundStyle(.indigo).frame(maxWidth:.infinity).padding(.vertical,14)
                    .background(Color.indigo.opacity(0.08),in:Capsule())
            }.accessibilityLabel("TV connection settings")
            Button { model.press(178) } label: { Image(systemName:"rectangle.portrait.and.arrow.right").font(.title3).foregroundStyle(ink).frame(width:40,height:44) }
                .disabled(!model.connected).accessibilityLabel("TV inputs")
        }
    }
    private var dpad: some View {
        ZStack {
            Circle().fill(ink)
            TVRemoteKey(symbol:"chevron.up",label:"Up",repeatable:true) { model.press(19) }.frame(width:48,height:48).offset(y:-73)
            TVRemoteKey(symbol:"chevron.down",label:"Down",repeatable:true) { model.press(20) }.frame(width:48,height:48).offset(y:73)
            TVRemoteKey(symbol:"chevron.left",label:"Left",repeatable:true) { model.press(21) }.frame(width:48,height:48).offset(x:-73)
            TVRemoteKey(symbol:"chevron.right",label:"Right",repeatable:true) { model.press(22) }.frame(width:48,height:48).offset(x:73)
            Button { model.press(23) } label: {
                Text("Select").font(.subheadline).foregroundStyle(.white).frame(width:82,height:82)
                    .background(ink,in:Circle()).overlay(Circle().stroke(.black.opacity(0.4),lineWidth:1))
            }.accessibilityLabel("Select on TV")
        }.frame(width:222,height:222).frame(maxWidth:.infinity)
    }
    private var navigationKeys: some View {
        HStack {
            roundKey("arrow.uturn.backward",label:"Back",code:4)
            Spacer()
            roundKey("house",label:"TV Home",code:3)
            Spacer()
            roundKey("line.3.horizontal",label:"TV menu",code:82)
        }.padding(.horizontal,18)
    }
    private func roundKey(_ symbol: String,label: String,code: UInt) -> some View {
        TVRemoteKey(symbol:symbol,label:label) { model.press(code) }.frame(width:48,height:48).background(ink,in:Circle())
    }
    private var volumeKeys: some View {
        HStack {
            VStack(spacing:0) {
                TVRemoteKey(symbol:"plus",label:"Volume up",repeatable:true) { model.press(24) }
                TVRemoteKey(symbol:"minus",label:"Volume down",repeatable:true) { model.press(25) }
            }.frame(width:60,height:112).background(ink,in:Capsule())
            Spacer()
            roundKey("speaker.slash",label:"Mute or unmute TV",code:164)
            Spacer()
            VStack(spacing:0) {
                TVRemoteKey(symbol:"chevron.up",label:"Channel up",repeatable:true) { model.press(166) }
                TVRemoteKey(symbol:"chevron.down",label:"Channel down",repeatable:true) { model.press(167) }
            }.frame(width:60,height:112).background(ink,in:Capsule())
        }.padding(.horizontal,18)
    }
    private var utilityKeys: some View {
        VStack(spacing:10) {
            HStack(spacing:12) {
                smallKey("gearshape",label:"TV settings") { model.press(176) }
                smallKey("keyboard",label:"Type on TV") { keyboardSheet = true }
                smallKey("textformat.123",label:"Number pad") { numberSheet = true }
                smallKey("magnifyingglass",label:"Search TV") { model.press(84); keyboardSheet = true }
            }
            HStack(spacing:12) {
                smallKey("play.fill",label:"Play") { model.press(126) }
                smallKey("pause.fill",label:"Pause") { model.press(127) }
                smallKey("backward.fill",label:"Rewind") { model.press(89) }
                smallKey("forward.fill",label:"Fast forward") { model.press(90) }
            }
        }
    }
    private func smallKey(_ symbol: String,label: String,action:@escaping () -> Void) -> some View {
        TVRemoteKey(symbol:symbol,label:label,action:action).frame(maxWidth:.infinity).frame(height:40).background(ink,in:Capsule())
    }
    private var appShortcuts: some View {
        HStack(alignment:.top,spacing:12) {
            ForEach(TVShortcut.allCases) { app in
                Button { model.launch(app) } label: {
                    VStack(spacing:6) {
                        Image(app.asset).resizable().interpolation(.high).scaledToFit().frame(width:48,height:48).clipShape(RoundedRectangle(cornerRadius:12))
                        Text(app.name).font(.caption2).foregroundStyle(ink).lineLimit(1)
                    }.frame(maxWidth:.infinity)
                }.accessibilityLabel("Open " + app.name + " on TV")
            }
        }.padding(.top,3)
    }
    private var connectionPanel: some View {
        NavigationStack {
            Form {
                Section("TV") {
                    TextField("TV IP address",text:$model.host).keyboardType(.numbersAndPunctuation).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text(model.status).font(.subheadline)
                    Button("Connect",action:model.connect).disabled(model.busy)
                    Button("Pair with TV",action:model.pair).disabled(model.busy)
                    if model.connected { Button("Disconnect",role:.destructive,action:model.disconnect) }
                }
                if model.awaitingCode {
                    Section("Code shown on TV") {
                        TextField("6-character code",text:$pairingCode).keyboardType(.asciiCapable).textInputAutocapitalization(.characters).autocorrectionDisabled()
                        Button("Verify code") { model.submitCode(pairingCode) }.disabled(model.busy || TVRemoteRules.pairingCode(pairingCode) == nil)
                    }
                }
            }.navigationTitle("Connect TV").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Done") { connectionSheet = false } } }
        }.presentationDetents([.medium,.large]).tint(.indigo)
    }
    private var keyboardPanel: some View {
        NavigationStack {
            Form {
                Section { TextField("Text for TV",text:$typedText).textInputAutocapitalization(.never).autocorrectionDisabled() }
                footer: { Text("First select a text field on the TV. Use letters, numbers, spaces or basic punctuation.") }
                Button("Send text") { if model.typeText(typedText) { typedText = ""; keyboardSheet = false } }.disabled(typedText.isEmpty)
                Button("Delete character") { model.press(67) }
                Button("Enter / Search") { model.press(66) }
            }.navigationTitle("TV keyboard").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Done") { keyboardSheet = false } } }
        }.presentationDetents([.medium]).tint(.indigo)
    }
    private var numericPanel: some View {
        NavigationStack {
            VStack(spacing:18) {
                LazyVGrid(columns:Array(repeating:GridItem(.flexible()),count:3),spacing:14) {
                    ForEach(1...9,id:\.self) { n in Button(String(n)) { model.press(UInt(n + 7)) }.font(.title2).frame(maxWidth:.infinity).frame(height:50) }
                    Button { model.press(67) } label: { Image(systemName:"delete.left") }
                    Button("0") { model.press(7) }.font(.title2)
                    Button { model.press(66) } label: { Image(systemName:"checkmark") }
                }.padding(24)
            }.navigationTitle("Number pad").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Done") { numberSheet = false } } }
        }.presentationDetents([.medium]).tint(.indigo)
    }
}

@MainActor private struct TVRemoteKey: View {
    let symbol: String
    let label: String
    var repeatable = false
    let action: () -> Void
    @State private var repeating: Task<Void,Never>?
    var body: some View {
        Button(action:action) { Image(systemName:symbol).font(.system(size:17,weight:.regular)).foregroundStyle(.white).frame(maxWidth:.infinity,maxHeight:.infinity).contentShape(Rectangle()) }
            .frame(minWidth:44,minHeight:44).accessibilityLabel(label)
            .onLongPressGesture(minimumDuration:0.35,pressing:{ down in if !down { repeating?.cancel(); repeating = nil } }) {
                guard repeatable else { return }
                repeating = Task { @MainActor in
                    while !Task.isCancelled { action(); try? await Task.sleep(nanoseconds:130_000_000) }
                }
            }
            .onDisappear { repeating?.cancel() }
    }
}
