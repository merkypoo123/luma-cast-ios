import SwiftUI

@MainActor
struct ContentView: View {
    @StateObject private var browser = BrowserModel()
    @StateObject private var playback = PlaybackModel()
    @State private var tab = 0
    @State private var address = ""
    @State private var direct = ""
    @State private var jump = ""
    @State private var dragging = false
    @State private var scrub = 0.0
    @State private var directError = ""

    var body: some View {
        TabView(selection: $tab) {
            browserPage.tabItem { Label("Browse", systemImage: "globe") }.tag(0)
            videosPage.tabItem { Label("Videos", systemImage: "film.stack") }.tag(1)
            playerPage.tabItem { Label("Player", systemImage: "play.rectangle") }.tag(2)
            savedPage.tabItem { Label("Saved", systemImage: "bookmark") }.tag(3)
        }
    }
    private var browserPage: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    TextField("Website address", text: $address).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL).submitLabel(.go).onSubmit(openPage)
                    Button(action: openPage) { Image(systemName: "arrow.right.circle.fill").font(.title2) }.accessibilityLabel("Open website")
                }.padding(12).background(.white.opacity(0.08))
                if browser.loading { ProgressView().progressViewStyle(.linear) }
                BrowserSurface(model: browser)
                HStack {
                    Button { browser.webView.goBack() } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Back")
                    Button { browser.webView.goForward() } label: { Image(systemName: "chevron.right") }.accessibilityLabel("Forward")
                    Button { browser.webView.reload() } label: { Image(systemName: "arrow.clockwise") }.accessibilityLabel("Reload")
                    Spacer()
                    Button { browser.scan(); tab = 1 } label: { Label("\(browser.streams.count)", systemImage: "film") }.accessibilityLabel("Detected videos")
                    Button { browser.saveBookmark() } label: { Image(systemName: "bookmark") }.accessibilityLabel("Save page")
                }.buttonStyle(.borderless).padding()
            }
            .navigationTitle("Luma Cast").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { browser.toggleBlocking() } label: { Image(systemName: browser.blocking ? "shield.lefthalf.filled" : "shield.slash") }
                        .accessibilityLabel(browser.blocking ? "Ad blocking on. Tap to turn off." : "Ad blocking off. Tap to turn on.")
                }
            }
            .onReceive(browser.$address) { if !$0.isEmpty { address = $0 } }
        }
    }
    private var videosPage: some View {
        NavigationStack {
            List {
                Section("Open a direct video link") {
                    TextField("MP4 or HLS URL", text: $direct).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Button("Open video") {
                        guard let url = MediaRules.httpURL(direct.trimmingCharacters(in: .whitespacesAndNewlines)), let kind = MediaRules.kind(url: url) else {
                            directError = "Use a complete MP4, MOV, audio or HLS link, rather than a video segment."
                            return
                        }
                        directError = ""
                        choose(Stream(url: url, title: "Direct video", kind: kind))
                    }
                    if !directError.isEmpty { Text(directError).font(.footnote).foregroundStyle(.orange) }
                }
                Section {
                    if browser.streams.isEmpty {
                        ContentUnavailableView("Find a video", systemImage: "film", description: Text("Open a website in Browse and start its video. Full HLS playlists and playable files appear here."))
                    }
                    ForEach(browser.streams) { stream in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(stream.title).font(.headline).lineLimit(2)
                            Text("\(stream.kind) · \(stream.url.host ?? "Video")").font(.caption).foregroundStyle(.secondary)
                            Button("Open in player") { choose(stream) }
                        }.padding(.vertical, 6)
                    }
                } header: { Text("Detected videos · \(browser.streams.count)") } footer: {
                    Text(browser.message + "\n\nSome sites protect their links with browser cookies. If a detected link fails, try the page player’s own AirPlay button. Detection is not a playback guarantee.")
                }
                Section {
                    Button("Try a public sample video") {
                        choose(Stream(url: URL(string: "https://media.w3.org/2010/05/sintel/trailer.mp4")!, title: "Sintel trailer · connection test", kind: "MP4"))
                    }
                }
            }.navigationTitle("Videos")
        }
    }
    private var playerPage: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    HStack {
                        Label(playback.external ? "ON AIRPLAY" : "IPHONE PLAYER", systemImage: playback.external ? "airplayvideo" : "iphone").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        AirPlayButton().frame(width: 44, height: 44).accessibilityLabel("Choose AirPlay TV")
                    }
                    Text(playback.title).font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
                    NativePlayer(player: playback.player).frame(height: 200).clipShape(RoundedRectangle(cornerRadius: 16))
                    VStack(spacing: 8) {
                        HStack { Text(MediaRules.clock(dragging ? scrub : playback.current)); Spacer(); Text(playback.duration > 0 ? MediaRules.clock(playback.duration) : "Live / unknown") }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        Slider(value: $scrub, in: 0...max(1, playback.duration), onEditingChanged: { editing in
                            dragging = editing
                            if !editing { playback.seek(scrub) }
                        }).disabled(!playback.canSeek).accessibilityLabel("Playback position")
                    }
                    HStack(spacing: 30) {
                        Button { playback.seek(max(0, playback.current - 10)) } label: { Image(systemName: "gobackward.10").font(.title) }.disabled(!playback.canSeek).accessibilityLabel("Back 10 seconds")
                        Button { playback.toggle() } label: { Image(systemName: playback.playing ? "pause.fill" : "play.fill").font(.title).frame(width: 80, height: 80).background(.cyan, in: Circle()).foregroundStyle(.black) }.disabled(!playback.hasItem).accessibilityLabel(playback.playing ? "Pause" : "Play")
                        Button { playback.seek(min(max(0, playback.duration - 1), playback.current + 30)) } label: { Image(systemName: "goforward.30").font(.title) }.disabled(!playback.canSeek).accessibilityLabel("Forward 30 seconds")
                        Button { playback.stop() } label: { Image(systemName: "stop.fill").font(.title2) }.disabled(!playback.hasItem).accessibilityLabel("Stop")
                    }
                    HStack {
                        TextField("Jump to 1:23:45", text: $jump).textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button("Go") {
                            guard let seconds = MediaRules.seconds(jump) else { playback.message = "Enter minutes:seconds or hours:minutes:seconds."; return }
                            playback.seek(seconds)
                        }.disabled(!playback.canSeek)
                    }
                    Text(playback.message).font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                    Text("Tap the AirPlay icon and choose Kayle. This sends media, not the iPhone screen. Your TV’s AirPlay receiver must be running.").font(.footnote).foregroundStyle(.secondary)
                }.padding(20)
            }.background(.black).navigationTitle("Player").navigationBarTitleDisplayMode(.inline)
                .onReceive(playback.$current) { if !dragging { scrub = min($0, max(1, playback.duration)) } }
        }
    }
    private var savedPage: some View {
        NavigationStack {
            List {
                if browser.bookmarks.isEmpty { ContentUnavailableView("No saved pages", systemImage: "bookmark", description: Text("Save a website using the bookmark button in Browse.")) }
                ForEach(browser.bookmarks) { bookmark in
                    Button { address = bookmark.url.absoluteString; browser.navigate(address); tab = 0 } label: {
                        VStack(alignment: .leading) { Text(bookmark.title); Text(bookmark.url.host ?? "").font(.caption).foregroundStyle(.secondary) }
                    }
                }
            }.navigationTitle("Saved")
        }
    }
    private func openPage() { browser.navigate(address) }
    private func choose(_ stream: Stream) { browser.webView.pauseAllMediaPlayback(completionHandler: nil); playback.load(stream); tab = 2 }
}
