import SwiftUI

@MainActor
struct ContentView: View {
    @StateObject private var browser = BrowserModel()
    @StateObject private var playback = PlaybackModel()
    @State private var tab = 0
    @State private var address = ""
    @State private var direct = ""
    @State private var jump = ""
    @State private var dragging = false
    @State private var scrub = 0.0
    @State private var directError = ""

    var body: some View {
        TabView(selection: $tab) {
            browserPage.tabItem { Label("Browse", systemImage: "globe") }.tag(0)
            videosPage.tabItem { Label("Videos", systemImage: "film.stack") }.tag(1)
            playerPage.tabItem { Label("Player", systemImage: "play.rectangle") }.tag(2)
            savedPage.tabItem { Label("Saved", systemImage: "bookmark") }.tag(3)
        }
    }
    private var browserPage: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    TextField("Website address", text: $address).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL).submitLabel(.go).onSubmit(openPage)
                    Button(action: openPage) { Image(systemName: "arrow.right.circle.fill").font(.title2) }.accessibilityLabel("Open website")
                }.padding(12).background(.white.opacity(0.08))
                if browser.loading { ProgressView().progressViewStyle(.linear) }
                ZStack {
                    BrowserSurface(model: browser).opacity(browser.isHome ? 0 : 1).allowsHitTesting(!browser.isHome)
                    if browser.isHome { startPage }
                }
                HStack {
                    Button { browser.showStartPage() } label: { Image(systemName: "house.fill") }.accessibilityLabel("Home — pinned websites")
                    Button { browser.webView.goBack() } label: { Image(systemName: "chevron.left") }.disabled(browser.isHome || !browser.webView.canGoBack).accessibilityLabel("Back")
                    Button { browser.webView.goForward() } label: { Image(systemName: "chevron.right") }.disabled(browser.isHome || !browser.webView.canGoForward).accessibilityLabel("Forward")
                    Button { browser.webView.reload() } label: { Image(systemName: "arrow.clockwise") }.disabled(browser.isHome).accessibilityLabel("Reload")
                    Spacer()
                    Button { browser.scan(); tab = 1 } label: { Label("\(browser.streams.count)", systemImage: "film") }.accessibilityLabel("Detected videos")
                    Button { browser.saveBookmark() } label: { Image(systemName: "bookmark") }.accessibilityLabel("Save page")
                }.buttonStyle(.borderless).padding()
            }
            .navigationTitle("Luma Cast").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { CastButton().frame(width: 36, height: 36).accessibilityLabel("Choose Google Cast TV") }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { browser.toggleBlocking() } label: { Image(systemName: browser.blocking ? "shield.lefthalf.filled" : "shield.slash") }
                        .accessibilityLabel(browser.blocking ? "Ad blocking on. Tap to turn off." : "Ad blocking off. Tap to turn on.")
                }
            }
            .onReceive(browser.$address) { address = $0 }
        }
    }
    private var startPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Your websites").font(.title.bold())
                    Text("Choose a pinned link or enter an address above.").font(.subheadline).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    ForEach(browser.pinnedSites) { site in
                        Button { browser.navigate(site.url.absoluteString) } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                Image(systemName: "globe").font(.title2).foregroundStyle(.cyan)
                                Text(site.title).font(.headline).foregroundStyle(.white).lineLimit(1)
                                Text(site.url.host?.replacingOccurrences(of: "www.", with: "") ?? "")
                                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
                                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
                        }.buttonStyle(.plain).accessibilityLabel("Open " + site.title)
                    }
                }
            }.padding(20)
        }.frame(maxWidth: .infinity, maxHeight: .infinity).background(.black)
    }

    private var videosPage: some View {
        NavigationStack {
            List {
                Section("Cast a direct video link") {
                    TextField("MP4 or HLS URL", text: $direct).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Button("Cast video") {
                        guard let url = MediaRules.httpURL(direct.trimmingCharacters(in: .whitespacesAndNewlines)), let kind = MediaRules.kind(url: url) else {
                            directError = "Use a complete MP4, MOV, audio or HLS link, rather than a video segment."
                            return
                        }
                        directError = ""
                        choose(Stream(url: url, title: "Direct video", kind: kind))
                    }
                    if !directError.isEmpty { Text(directError).font(.footnote).foregroundStyle(.orange) }
                }
                Section {
                    if browser.streams.isEmpty {
                        ContentUnavailableView("Find a video", systemImage: "film", description: Text("Open a website in Browse and start its video. Full HLS playlists and playable files appear here."))
                    }
                    ForEach(browser.streams) { stream in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(stream.title).font(.headline).lineLimit(2)
                            if stream.isMasterPlaylist { Label("Full HLS playlist", systemImage: "speaker.wave.2").font(.caption).foregroundStyle(.cyan) }
                            Text("Website: \(stream.sourceHost)").font(.subheadline)
                            Text("\(stream.kind) Â· Media server: \(stream.url.host ?? "Unknown")").font(.caption).foregroundStyle(.secondary)
                            Text(stream.playlistText != nil ? "Served by your iPhone while connecting" : stream.fileLabel).font(.caption).foregroundStyle(.secondary).lineLimit(1).truncationMode(.middle)
                            if let embed = stream.embedPage?.host, embed != stream.sourceHost {
                                Text("Player: \(embed)").font(.caption).foregroundStyle(.secondary)
                            }
                            Button("Cast to TV") { choose(stream) }
                        }.padding(.vertical, 6)
                    }
                } header: { Text("Detected videos Â· \(browser.streams.count)") } footer: {
                    Text(browser.message + "\n\nSome sites protect their links with browser cookies. The TV must be able to fetch the link directly. Try another server if a link fails.")
                }
                Section {
                    Button("Try a public sample video") {
                        choose(Stream(url: URL(string: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4")!, title: "Flowers Â· short connection test", kind: "MP4"))
                    }
                }
            }.navigationTitle("Videos")
        }
    }
    private var playerPage: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    HStack {
                        Label(playback.connected ? playback.deviceName : "CONNECT YOUR TV", systemImage: "tv").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        CastButton().frame(width: 44, height: 44).accessibilityLabel("Choose Google Cast TV")
                    }
                    Text(playback.title).font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
                    Text(playback.message).font(.callout).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12).background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                    VStack(spacing: 16) { Image(systemName: "tv").font(.system(size: 64)).foregroundStyle(.cyan); Text(playback.playing ? "Playing on your TV" : playback.isLoading ? "Waiting for TV playback" : playback.connected ? "TV connected" : "Tap Cast and choose Kayle").foregroundStyle(.secondary); if playback.isLoading { ProgressView() } }.frame(maxWidth: .infinity).frame(height: 180).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16))
                    VStack(spacing: 8) {
                        HStack { Text(MediaRules.clock(dragging ? scrub : playback.current)); Spacer(); Text(playback.duration > 0 ? MediaRules.clock(playback.duration) : "Live / unknown") }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        Slider(value: $scrub, in: 0...max(1, playback.duration), onEditingChanged: { editing in
                            dragging = editing
                            if !editing { playback.seek(scrub) }
                        }).disabled(!playback.canSeek).accessibilityLabel("Playback position")
                    }
                    HStack(spacing: 30) {
                        Button { playback.seek(max(0, playback.current - 10)) } label: { Image(systemName: "gobackward.10").font(.title) }.disabled(!playback.canSeek).accessibilityLabel("Back 10 seconds")
                        Button { playback.toggle() } label: { Image(systemName: playback.playing ? "pause.fill" : "play.fill").font(.title).frame(width: 80, height: 80).background(.cyan, in: Circle()).foregroundStyle(.black) }.disabled(!playback.hasItem).accessibilityLabel(playback.playing ? "Pause" : "Play")
                        Button { playback.seek(min(max(0, playback.duration - 1), playback.current + 30)) } label: { Image(systemName: "goforward.30").font(.title) }.disabled(!playback.canSeek).accessibilityLabel("Forward 30 seconds")
                        Button { playback.stop() } label: { Image(systemName: "stop.fill").font(.title2) }.disabled(!playback.hasItem).accessibilityLabel("Stop")
                    }
                    HStack {
                        TextField("Jump to 1:23:45", text: $jump).textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button("Go") {
                            guard let seconds = MediaRules.seconds(jump) else { playback.message = "Enter minutes:seconds or hours:minutes:seconds."; return }
                            playback.seek(seconds)
                        }.disabled(!playback.canSeek)
                    }
                    Button("TV volume and full controls") { playback.showFullControls() }.disabled(!playback.connected || !playback.hasItem)
                    Button("Retry selected video") { playback.retry() }.disabled(!playback.connected || playback.isLoading)
                    if !playback.activity.isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Cast activity").font(.headline)
                            Text(playback.activity.joined(separator: "\n")).font(.caption.monospaced()).textSelection(.enabled)
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                    Text("Luma Cast \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "") · build \(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "")").font(.caption).foregroundStyle(.secondary)
                    Text("Tap the Cast icon and choose Kayle. Your TV uses its built-in Chromecast receiver; the PC can stay off.").font(.footnote).foregroundStyle(.secondary)
                }.padding(20)
            }.background(.black).navigationTitle("Player").navigationBarTitleDisplayMode(.inline)
                .onReceive(playback.$current) { if !dragging { scrub = min($0, max(1, playback.duration)) } }
                .onReceive(playback.$playing) { if $0 { browser.webView.pauseAllMediaPlayback(completionHandler: nil) } }
        }
    }
    private var savedPage: some View {
        NavigationStack {
            List {
                if browser.bookmarks.isEmpty { ContentUnavailableView("No saved pages", systemImage: "bookmark", description: Text("Save a website using the bookmark button in Browse.")) }
                ForEach(browser.bookmarks) { bookmark in
                    Button { address = bookmark.url.absoluteString; browser.navigate(address); tab = 0 } label: {
                        VStack(alignment: .leading) { Text(bookmark.title); Text(bookmark.url.host ?? "").font(.caption).foregroundStyle(.secondary) }
                    }
                }
            }.navigationTitle("Saved")
        }
    }
    private func openPage() { browser.navigate(address) }
    private func choose(_ stream: Stream) { playback.load(stream); tab = 2 }
}
