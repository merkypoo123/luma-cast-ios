import Foundation

// A credential-free, bounded preflight; receiver playback is the final compatibility test.
final class DirectMediaProbe {
    struct Decision { let direct: Bool; let reason: String; var audioFMP4 = false; var videoFMP4 = false }
    private let session: URLSession
    private let deadline: Date
    private var visited = Set<URL>()
    private var requests = 0
    private var expectedRoot: String?
    private var audioFMP4 = false
    private var videoFMP4 = false
    private var formats: [URL: Bool] = [:]
    init(configuration: URLSessionConfiguration = .ephemeral) {
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.urlCache = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 4
        configuration.timeoutIntervalForResource = 5
        session = URLSession(configuration: configuration)
        deadline = Date().addingTimeInterval(15)
    }
    deinit { session.invalidateAndCancel() }
    func evaluate(_ stream: Stream) async throws -> Decision {
        guard MediaRules.httpURL(stream.url.absoluteString) != nil else {
            return Decision(direct: false, reason: "Browser-created playlist requires relay; original audio/video links must be preserved")
        }
        guard ["HLS", "MP4", "MOV", "WebM", "Audio"].contains(stream.kind) else {
            return Decision(direct: true, reason: "Existing direct path for DASH; not credential-probed")
        }
        expectedRoot = stream.playlistText
        do {
            if stream.kind == "HLS" { _ = try await playlist(stream.url, depth: 0) }
            else { _ = try await fetch(stream.url, playlist: false) }
            return Decision(direct: true, reason: "Credential-free media preflight passed; TV will fetch the source directly", audioFMP4: audioFMP4, videoFMP4: videoFMP4)
        } catch is CancellationError { throw CancellationError() }
        catch { return Decision(direct: false, reason: "Credential-free preflight failed; browser context or media normalization may be needed") }
    }
    private enum Failure: Error { case rejected }
    private func fetch(_ url: URL, playlist: Bool, key: Bool = false) async throws -> (Data, URL) {
        try Task.checkCancellation()
        requests += 1
        guard requests <= 32, Date() < deadline, MediaRules.httpURL(url.absoluteString) != nil else { throw Failure.rejected }
        var request = URLRequest(url: url)
        request.setValue("https://www.gstatic.com", forHTTPHeaderField: "Origin")
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        if !playlist { request.setValue("bytes=0-1023", forHTTPHeaderField: "Range") }
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode),
              http.value(forHTTPHeaderField: "Access-Control-Allow-Origin") == "*" || http.value(forHTTPHeaderField: "Access-Control-Allow-Origin") == "https://www.gstatic.com" else { throw Failure.rejected }
        var data = Data()
        let limit = playlist ? 512 * 1024 : 1024
        for try await byte in bytes {
            try Task.checkCancellation()
            if Date() >= deadline { throw Failure.rejected }
            if data.count >= limit { if playlist { throw Failure.rejected }; break }
            data.append(byte)
        }
        guard !data.isEmpty else { throw Failure.rejected }
        if !playlist && !key {
            let supplied = http.mimeType ?? "application/octet-stream"
            // A receiver cannot use our proxy's MIME repair when sent the real URL.
            guard supplied.hasPrefix("video/") || supplied.hasPrefix("audio/") || supplied == "application/octet-stream" else { throw Failure.rejected }
            let text = String(data: data.prefix(128), encoding: .utf8)?.lowercased() ?? ""
            guard !text.contains("<html"), !text.contains("<!doctype") else { throw Failure.rejected }
        }
        return (data, http.url ?? url)
    }
    private func playlist(_ url: URL, depth: Int) async throws -> Bool {
        guard depth < 4 else { throw Failure.rejected }
        if visited.contains(url) { guard let known = formats[url] else { throw Failure.rejected }; return known }
        visited.insert(url)
        let (data, finalURL) = try await fetch(url, playlist: true)
        guard let text = String(data: data, encoding: .utf8), !text.contains("#EXT-X-DEFINE"),
              !text.contains("#EXT-X-SESSION-KEY"), let normalized = HLSPlaylist.normalized(text, baseURL: finalURL) else { throw Failure.rejected }
        if depth == 0, let expectedRoot {
            guard let captured = HLSPlaylist.normalized(expectedRoot, baseURL: url), captured.trimmingCharacters(in: .whitespacesAndNewlines) == normalized.trimmingCharacters(in: .whitespacesAndNewlines) else { throw Failure.rejected }
        }
        var children = Set<URL>(), segments: [URL] = [], auxiliary = Set<URL>()
        let master = normalized.contains("#EXT-X-STREAM-INF:")
        let regex = try NSRegularExpression(pattern: "URI=\"([^\"]+)\"")
        for line in normalized.components(separatedBy: .newlines) {
            if !line.isEmpty && !line.hasPrefix("#"), let value = URL(string: line) {
                if master { children.insert(value) } else { segments.append(value) }
            }
            for match in regex.matches(in: line, range: NSRange(line.startIndex..., in: line)) {
                guard let range = Range(match.range(at: 1), in: line), let value = MediaRules.httpURL(String(line[range])) else { throw Failure.rejected }
                if line.hasPrefix("#EXT-X-MEDIA:") || line.hasPrefix("#EXT-X-I-FRAME-STREAM-INF:") { children.insert(value) }
                else { auxiliary.insert(value) }
            }
        }
        guard children.count <= 12, auxiliary.count <= 8, !children.isEmpty || !segments.isEmpty else { throw Failure.rejected }
        var anyFMP4 = normalized.contains("#EXT-X-MAP:")
        let selected = HLSPlaylist.childPlaylists(normalized)
        for child in children.sorted(by: { $0.absoluteString < $1.absoluteString }) {
            let fmp4 = try await playlist(child, depth: depth + 1)
            anyFMP4 = anyFMP4 || fmp4
            if depth == 0, child == selected.audio { audioFMP4 = fmp4 }
            if depth == 0, child == selected.video { videoFMP4 = fmp4 }
        }
        if depth == 0 && !master { audioFMP4 = anyFMP4; videoFMP4 = anyFMP4 }
        for resource in auxiliary { _ = try await fetch(resource, playlist: false, key: true) }
        // Sample first/last segments, not an entire movie. Tokens can still expire later.
        for resource in Set([segments.first, segments.last].compactMap { $0 }) { _ = try await fetch(resource, playlist: false) }
        formats[url] = anyFMP4
        return anyFMP4
    }
}
