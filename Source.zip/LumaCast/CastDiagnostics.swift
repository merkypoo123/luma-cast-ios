import Foundation
import OSLog

// Diagnostic build only. Callers supply state/counters, never URLs, tokens, cookies or headers.
enum CastDiagnostics {
    private static let logger = Logger(subsystem: "dev.kayle.lumacast", category: "CastLifecycle")
    private static let lock = NSLock()
    static var file: URL { FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("CastDiagnostics.log") }
    static func event(_ message: String) {
        logger.notice("\(message, privacy: .public)")
        lock.lock(); defer { lock.unlock() }
        let url = file
        if let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize, size > 1_048_576 {
            let previous = url.deletingLastPathComponent().appendingPathComponent("CastDiagnostics.previous.log")
            try? FileManager.default.removeItem(at: previous)
            try? FileManager.default.moveItem(at: url, to: previous)
        }
        let line = Data((ISO8601DateFormatter().string(from: Date()) + " " + message + "\n").utf8)
        if !FileManager.default.fileExists(atPath: url.path) { FileManager.default.createFile(atPath: url.path, contents: nil) }
        if let handle = try? FileHandle(forWritingTo: url) { defer { try? handle.close() }; do { try handle.seekToEnd(); try handle.write(contentsOf: line) } catch {} }
    }
    static func error(_ error: Error) -> String { let e = error as NSError; return e.domain + ":" + String(e.code) }
    static func export() -> URL {
        lock.lock(); defer { lock.unlock() }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("LumaCast-background-diagnostics.txt")
        var all = (try? Data(contentsOf: file.deletingLastPathComponent().appendingPathComponent("CastDiagnostics.previous.log"))) ?? Data()
        all.append((try? Data(contentsOf: file)) ?? Data())
        try? all.write(to: output, options: .atomic)
        return output
    }
}
