import Foundation
import Combine
import Security
import CryptoKit
import AndroidTVRemoteControl

private final class TVRemoteTrust: @unchecked Sendable {
    private let lock = NSLock()
    let pairing: Bool
    let expected: Data?
    private var observed: Data?
    init(pairing: Bool, expected: Data?) { self.pairing = pairing; self.expected = expected }
    func accept(_ trust: SecTrust) -> Bool {
        guard let certificate = SecTrustGetCertificateAtIndex(trust,0) else { return false }
        let fingerprint = Data(SHA256.hash(data:SecCertificateCopyData(certificate) as Data))
        lock.lock(); observed = fingerprint; lock.unlock()
        return pairing || expected == fingerprint
    }
    func fingerprint() -> Data? { lock.lock(); defer { lock.unlock() }; return observed }
}

@MainActor final class TVRemoteModel: ObservableObject {
    @Published var host = UserDefaults.standard.string(forKey:"remoteHost") ?? "192.168.0.13"
    @Published var name = "Kayle"
    @Published var status = "Pair with your TV to use the remote."
    @Published var connected = false
    @Published var busy = false
    @Published var awaitingCode = false
    private let queue = DispatchQueue(label:"dev.kayle.lumacast.remote.commands")
    private var pairing: PairingManager?
    private var controller: RemoteManager?
    private var trust: TVRemoteTrust?
    private var operation = UUID()
    private var commandTask: Task<Void,Never>?

    func connectIfPaired() {
        guard !connected, !busy, let value = TVRemoteRules.host(host), TVRemoteSecrets.pin(value) != nil else { return }
        start(pair: false)
    }
    func connect() { start(pair:false) }
    func pair() { start(pair:true) }
    func disconnect() {
        operation = UUID(); commandTask?.cancel()
        pairing?.disconnect(); controller?.disconnect()
        pairing = nil; controller = nil; trust = nil
        connected = false; busy = false; awaitingCode = false
        status = "Disconnected."
    }
    private func start(pair: Bool) {
        guard let value = TVRemoteRules.host(host) else { status = "Enter a valid TV IP address or hostname."; return }
        disconnect(); host = value
        let token = operation
        let pin = TVRemoteSecrets.pin(value)
        guard pair || pin != nil else { status = "Tap Pair, then enter the code shown on the TV."; return }
        busy = true; status = pair ? "Requesting a pairing code on the TV…" : "Connecting to TV…"
        Task {
            do {
                let identity = try await Task.detached(priority:.userInitiated) { try TVRemoteIdentity.loadOrCreate() }.value
                guard self.operation == token else { return }
                let crypto = CryptoManager()
                crypto.clientPublicCertificate = { .Result(identity.publicKey) }
                let trust = TVRemoteTrust(pairing:pair,expected:pin)
                let tls = TLSManager { .Result([[kSecImportItemIdentity as String:identity.identity]] as CFArray) }
                tls.verifyServer = { trust.accept($0) }
                tls.secTrustClosure = { server in
                    crypto.serverPublicCertificate = {
                        guard let key = SecTrustCopyKey(server) else { return .Error(.secTrustCopyKeyError) }
                        return .Result(key)
                    }
                }
                self.trust = trust
                if pair {
                    let manager = PairingManager(tls,crypto)
                    self.pairing = manager
                    manager.stateChanged = { [weak self] state in Task { @MainActor in
                        guard let self, self.operation == token else { return }
                        switch state {
                        case .waitingCode: self.busy = false; self.awaitingCode = true; self.status = "Enter the six-character code shown on your TV."
                        case .successPaired:
                            guard let fingerprint = trust.fingerprint() else { self.busy = false; self.status = "Could not verify the TV. Pair again."; return }
                            do { try TVRemoteSecrets.savePin(fingerprint,host:value); UserDefaults.standard.set(value,forKey:"remoteHost"); self.start(pair:false) }
                            catch { self.busy = false; self.status = error.localizedDescription }
                        case .error(let error):
                            self.busy = false
                            switch error { case .wrongCode, .invalidCode: self.awaitingCode = true; self.status = "That code did not match. Check the TV and retry."; default: self.status = "Pairing failed. Keep the TV awake and tap Pair again." }
                        default: break
                        }
                    } }
                    queue.async { manager.connect(value,"Luma Cast","iPhone",timeout:15) }
                } else {
                    let manager = RemoteManager(tls,CommandNetwork.DeviceInfo("iPhone","Apple","1.0","Luma Cast","12"))
                    self.controller = manager
                    manager.stateChanged = { [weak self] state in Task { @MainActor in
                        guard let self, self.operation == token else { return }
                        switch state {
                        case .paired:
                            self.connected = true; self.busy = false; self.awaitingCode = false; self.status = "Connected to \(self.name)"
                            UserDefaults.standard.set(value,forKey:"remoteHost")
                        case .error:
                            self.connected = false; self.busy = false
                            self.status = "Could not connect. Keep the TV awake; pair again if its credentials changed."
                        default: break
                        }
                    } }
                    queue.async { manager.connect(value,timeout:15) }
                }
            } catch { if self.operation == token { self.busy = false; self.status = error.localizedDescription } }
        }
    }
    func submitCode(_ raw: String) {
        guard let code = TVRemoteRules.pairingCode(raw), let pairing else { status = "Use the six letters and numbers shown on the TV."; return }
        busy = true; status = "Verifying TV code…"
        queue.async { pairing.sendSecret(code) }
    }
    func press(_ code: UInt) {
        commandTask?.cancel()
        guard connected else { status = "Connect or pair with the TV first."; return }
        send(code)
    }
    private func send(_ code: UInt, direction: Direction = .SHORT) {
        guard let controller, let key = Key(rawValue:code) else { return }
        queue.async { controller.send(KeyPress(key,direction)) }
    }
    func launch(_ app: TVShortcut) {
        commandTask?.cancel()
        guard connected else { status = "Connect or pair with the TV first."; return }
        if let link = app.appLink, let controller { queue.async { controller.send(DeepLink(link)) }; return }
        guard let steps = app.shelfPosition else { return }
        commandTask = Task {
            do {
                self.send(3); try await Task.sleep(nanoseconds:800_000_000)
                self.send(3); try await Task.sleep(nanoseconds:800_000_000)
                for _ in 0..<steps { try Task.checkCancellation(); self.send(22); try await Task.sleep(nanoseconds:180_000_000) }
                try Task.checkCancellation(); self.send(23)
            } catch {}
        }
    }
    func typeText(_ text: String) -> Bool {
        guard connected else { status = "Connect the TV first."; return false }
        guard let presses = TVRemoteRules.text(text) else { status = "Use up to 200 letters, numbers, spaces or basic punctuation."; return false }
        commandTask?.cancel()
        commandTask = Task {
            do {
                for item in presses {
                    try Task.checkCancellation()
                    if item.shift { self.send(59,direction:.START_LONG) }
                    self.send(item.code)
                    if item.shift { self.send(59,direction:.END_LONG) }
                    try await Task.sleep(nanoseconds:40_000_000)
                }
            } catch {}
        }
        return true
    }
}
