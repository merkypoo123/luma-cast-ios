import Foundation
import SwiftUI
import Combine
import GoogleCastDynamic

@MainActor
enum CastBootstrap {
    private static var configured = false
    static func configure() {
        guard !configured else { return }
        configured = true
        let discovery = GCKDiscoveryCriteria(applicationID: kGCKDefaultMediaReceiverApplicationID)
        let options = GCKCastOptions(discoveryCriteria: discovery)
        GCKCastContext.setSharedInstanceWith(options)
        GCKCastContext.sharedInstance().useDefaultExpandedMediaControls = true
    }
}

@MainActor
final class PlaybackModel: NSObject, ObservableObject, GCKSessionManagerListener, GCKRemoteMediaClientListener, GCKRequestDelegate {
    weak var browser: BrowserModel?
    @Published var title = "Nothing playing"
    @Published var current = 0.0
    @Published var duration = 0.0
    @Published var playing = false
    @Published var connected = false
    @Published var deviceName = "Choose your TV"
    @Published var message = "Tap the Cast button and choose Kayle."
    @Published var hasItem = false
    @Published var canSeek = false
    @Published var isLoading = false
    @Published private(set) var activity: [String] = []
    private var pending: Stream?
    private var remote: GCKRemoteMediaClient?
    private var loadRequest: GCKRequest?
    private var lastStatusEvent = ""
    private var timer: Timer?
    private var awaitingURL: String?
    private var loadingSince: Date?
    private var lastStream: Stream?
    private var relayFailure: String?
    private let playlistServer = PlaylistServer()
    private var preparation: Task<Void, Never>?
    private let manager: GCKSessionManager

    override init() {
        CastBootstrap.configure()
        manager = GCKCastContext.sharedInstance().sessionManager
        super.init()
        manager.add(self)
        if let session = manager.currentCastSession, session.connectionState == .connected { attach(session) }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self = self else { return }
                if let started = self.loadingSince, Date().timeIntervalSince(started) > 45 {
                    self.loadingSince = nil
                    self.awaitingURL = nil
                    self.isLoading = false
                    self.message = "The TV did not start this video within 45 seconds. See Cast activity below."
                    self.record("Load timed out after 45 seconds")
                }
                guard self.hasItem, let remote = self.remote else { return }
                let time = remote.approximateStreamPosition()
                if time.isFinite { self.current = max(0, time) }
            }
        }
    }
    deinit { timer?.invalidate() }

    private func record(_ event: String) {
        activity.append(event)
        activity = Array(activity.suffix(24))
    }

    func load(_ stream: Stream) {
        preparation?.cancel()
        lastStream = stream
        relayFailure = nil
        // DASH requires template-aware manifest routing; retain its direct path for now.
        guard stream.kind != "DASH" else { loadPrepared(stream); return }
        title = stream.title
        message = "Preparing media through your iPhone. Keep Luma open while casting…"
        isLoading = true
        preparation = Task { [weak self] in
            guard let self else { return }
            do {
                let context = await self.browser?.requestContext(for: stream) ?? BrowserRequestContext(referer: stream.embedPage ?? stream.sourcePage, userAgent: "Mozilla/5.0", cookies: [])
                self.playlistServer.onError = { [weak self] event in Task { @MainActor in
                    guard let self else { return }
                    self.relayFailure = event; self.message = event; self.record(event)
                } }
                self.playlistServer.onEvent = { [weak self] event in Task { @MainActor in self?.record(event) } }
                var prepared = stream
                if stream.kind == "HLS", prepared.playlistText == nil,
                   let text = await self.readPlaylist(stream.url, context: context, limit: 4 * 1024 * 1024),
                   let normalized = HLSPlaylist.normalized(text, baseURL: stream.url) {
                    prepared.playlistText = normalized
                }
                let url = try await self.playlistServer.relay(prepared, context: context)
                let children = prepared.playlistText.map(HLSPlaylist.childPlaylists)
                async let audio = self.usesFragmentedMP4(children?.audio, context: context)
                async let video = self.usesFragmentedMP4(children?.video, context: context)
                let formats = await (audio, video)
                let combinedFMP4 = prepared.playlistText?.contains("#EXT-X-MAP:") == true
                try Task.checkCancellation()
                self.loadPrepared(Stream(url: url, title: stream.title, kind: stream.kind, hlsAudioFMP4: formats.0 || combinedFMP4,
                                         hlsVideoFMP4: formats.1 || combinedFMP4, isMasterPlaylist: stream.isMasterPlaylist,
                                         sourcePage: stream.sourcePage, embedPage: stream.embedPage))
                self.record(stream.playlistText != nil ? "Using browser-captured HLS contents" : "Using fetched media link")
            } catch is CancellationError { return }
            catch { self.isLoading = false; self.message = error.localizedDescription }
        }
    }

    private func usesFragmentedMP4(_ url: URL?, context: BrowserRequestContext) async -> Bool {
        guard let url else { return false }
        return await readPlaylist(url, context: context, limit: 64 * 1024)?.contains("#EXT-X-MAP:") == true
    }

    private func readPlaylist(_ url: URL, context: BrowserRequestContext, limit: Int) async -> String? {
        var request = context.request(url)
        request.timeoutInterval = 8
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            var data = Data()
            for try await byte in bytes {
                if data.count >= limit { if limit > 64 * 1024 { return nil }; break }
                data.append(byte)
                if data.count == 64, !(String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") ?? false) { return nil }
            }
            guard let text = String(data: data, encoding: .utf8), text.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") else { return nil }
            return text
        } catch { return nil }
    }

    private func loadPrepared(_ stream: Stream) {
        isLoading = false
        guard MediaRules.httpURL(stream.url.absoluteString) != nil,
              MediaRules.kind(url: stream.url, contentType: MediaRules.mimeType(for: stream)) != nil else {
            message = "Choose a full video file or playlist."
            return
        }
        activity.removeAll()
        record("Selected \(stream.kind) from \(stream.url.host ?? "unknown host")")
        pending = nil
        // Re-read the live SDK session instead of relying on cached UI state.
        if let session = manager.currentCastSession, session.connectionState == .connected {
            if remote !== session.remoteMediaClient || !connected { attach(session) }
        } else {
            remote?.remove(self)
            remote = nil
            connected = false
        }
        pending = stream
        title = stream.title
        if connected && remote == nil {
            message = "Connected, but the TV media channel is unavailable. Disconnect using Cast, then reconnect."
            record("Connected session has no media client")
            return
        }
        if !connected {
            message = "Video selected. Tap Cast and choose Kayle to start."
            record("Waiting for a Cast connection")
            return
        }
        sendPending()
    }

    private func sendPending() {
        guard let stream = pending, connected, let remote = remote else { return }
        pending = nil
        lastStatusEvent = ""
        awaitingURL = stream.url.absoluteString
        loadingSince = Date()
        title = stream.title
        current = 0; duration = 0; hasItem = false; canSeek = false; playing = false; isLoading = true
        message = "Loading on \(deviceName)â€¦"
        let metadata = GCKMediaMetadata(metadataType: .movie)
        metadata.setString(stream.title, forKey: kGCKMetadataKeyTitle)
        let info = GCKMediaInformationBuilder(contentURL: stream.url)
        // Older receivers and status messages may use contentId rather than contentUrl.
        info.contentID = stream.url.absoluteString
        info.contentType = MediaRules.mimeType(for: stream)
        info.streamType = .buffered
        if stream.hlsAudioFMP4 { info.hlsSegmentFormat = .FMP4 }
        if stream.hlsVideoFMP4 { info.hlsVideoSegmentFormat = .FMP4 }
        info.metadata = metadata
        let request = GCKMediaLoadRequestDataBuilder()
        request.mediaInformation = info.build()
        request.autoplay = true
        let data = request.build()
        let sent = remote.loadMedia(with: data)
        loadRequest = sent
        sent.delegate = self
        record("Sent LOAD #\(sent.requestID) to \(deviceName)")
        if let error = sent.error { self.request(sent, didFailWithError: error) }
    }

    func retry() { if let stream = lastStream { load(stream) } }

    func toggle() {
        guard connected, hasItem, let remote = remote else { return }
        if playing { remote.pause().delegate = self } else { remote.play().delegate = self }
    }
    func stop() {
        preparation?.cancel()
        pending = nil
        awaitingURL = nil
        loadingSince = nil
        guard connected, let remote = remote else { clearPlayback(); message = "Stopped."; return }
        remote.stop().delegate = self
    }
    func seek(_ seconds: Double) {
        guard connected, hasItem, canSeek, seconds.isFinite, seconds >= 0, seconds < duration, let remote = remote else {
            message = "Choose a time within a seekable video."
            return
        }
        let options = GCKMediaSeekOptions()
        options.interval = seconds
        options.relative = false
        // The default unchanged resume state preserves pause/play while jumping.
        remote.seek(with: options).delegate = self
    }
    func showFullControls() { GCKCastContext.sharedInstance().presentDefaultExpandedMediaControls() }

    private func attach(_ session: GCKCastSession) {
        remote?.remove(self)
        remote = session.remoteMediaClient
        remote?.add(self)
        record("Cast session ready: \(session.device.friendlyName ?? "TV")")
        connected = true
        deviceName = session.device.friendlyName ?? "Cast TV"
        message = "Connected to \(deviceName). Choose a video to cast."
        if pending != nil { sendPending() } else { update(remote?.mediaStatus) }
    }
    private func detach(_ text: String) {
        record(text)
        loadRequest = nil
        remote?.remove(self)
        remote = nil
        connected = false
        awaitingURL = nil
        clearPlayback()
        message = text
    }
    private func clearPlayback() {
        current = 0; duration = 0; hasItem = false; playing = false; canSeek = false; isLoading = false
        loadingSince = nil
    }
    private func update(_ status: GCKMediaStatus?) {
        guard let status = status else { return }
        let state: String
        switch status.playerState {
        case .playing: state = "playing"
        case .paused: state = "paused"
        case .buffering: state = "buffering"
        case .loading: state = "loading"
        case .idle: state = "idle (reason \(status.idleReason.rawValue))"
        default: state = "unknown"
        }
        let event = "TV reports " + state
        if event != lastStatusEvent { record(event); lastStatusEvent = event }
        if status.playerState == .idle {
            if let expected = awaitingURL, let info = status.mediaInformation,
               !MediaRules.matchesCastMedia(expected: expected, contentID: info.contentID, contentURL: info.contentURL) { return }
            if awaitingURL != nil && status.idleReason != .error { return }
            awaitingURL = nil
            clearPlayback()
            if status.idleReason == .finished {
                message = "Video finished. The sample is only a few seconds long."
                return
            }
            message = status.idleReason == .error ? (relayFailure ?? "The TV reported a media load error. Cast activity below shows whether the TV requested the playlist and video segments.") : "Playback stopped."
            return
        }
        guard let info = status.mediaInformation else { return }
        if let expected = awaitingURL,
           !MediaRules.matchesCastMedia(expected: expected, contentID: info.contentID, contentURL: info.contentURL) { return }
        awaitingURL = nil
        hasItem = true
        playing = status.playerState == .playing
        isLoading = status.playerState == .buffering || status.playerState == .loading
        if isLoading {
            if loadingSince == nil { loadingSince = Date() }
        } else { loadingSince = nil }
        let length = info.streamDuration
        duration = length.isFinite ? max(0, length) : 0
        current = status.streamPosition.isFinite ? max(0, status.streamPosition) : 0
        canSeek = duration > 0 && status.isMediaCommandSupported(kGCKMediaCommandSeek)
        title = info.metadata?.string(forKey: kGCKMetadataKeyTitle) ?? title
        if isLoading { message = "Buffering on \(deviceName)â€¦" }
        else { message = playing ? "Playing on \(deviceName)" : "Paused on \(deviceName)" }
    }

    func sessionManager(_ sessionManager: GCKSessionManager, didStart session: GCKSession) {
        if let cast = session as? GCKCastSession { attach(cast) }
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didResumeSession session: GCKSession) {
        if let cast = session as? GCKCastSession { attach(cast) }
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didEnd session: GCKSession, withError error: Error?) {
        pending = nil
        detach(error == nil ? "Disconnected. Tap Cast to reconnect." : "Cast connection ended. Tap Cast to reconnect.")
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didFailToStart session: GCKSession, withError error: Error) {
        pending = nil
        detach("Could not connect to the TV. Check Wi-Fi and allow Local Network access in iPhone Settings.")
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didSuspend session: GCKSession, with reason: GCKConnectionSuspendReason) {
        detach("Cast connection interrupted. Waiting for reconnectionâ€¦")
    }
    func remoteMediaClient(_ client: GCKRemoteMediaClient, didUpdate mediaStatus: GCKMediaStatus?) { update(mediaStatus) }
    func requestDidComplete(_ request: GCKRequest) {
        guard request.requestID == loadRequest?.requestID else { return }
        record("TV acknowledged LOAD #\(request.requestID)")
        update(remote?.mediaStatus)
    }
    func request(_ request: GCKRequest, didAbortWith abortReason: GCKRequestAbortReason) {
        guard request.requestID == loadRequest?.requestID else { return }
        record("LOAD #\(request.requestID) tracking ended: \(abortReason.rawValue)")
    }
    func request(_ request: GCKRequest, didFailWithError error: GCKError) {
        record("Request #\(request.requestID) failed: \(error.code) \(error.localizedDescription)")
        // An old load or a failed control request must not clear a newer pending load.
        if let loadRequest, request.requestID != loadRequest.requestID {
            message = "Cast control failed (\(error.code)): \(error.localizedDescription)"
            return
        }
        awaitingURL = nil
        isLoading = false
        loadingSince = nil
        message = "Cast request failed (code \(error.code)): \(error.localizedDescription). Try the public sample or another source."
    }
}

struct CastButton: UIViewRepresentable {
    func makeUIView(context: Context) -> GCKUICastButton {
        let button = GCKUICastButton(frame: .zero)
        button.tintColor = .cyan
        return button
    }
    func updateUIView(_ button: GCKUICastButton, context: Context) {}
}
