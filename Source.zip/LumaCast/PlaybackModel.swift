import Foundation
import AVFoundation
import AVKit
import SwiftUI
import Combine

@MainActor
final class PlaybackModel: ObservableObject {
    let player = AVPlayer()
    @Published var title = "Nothing playing"
    @Published var current = 0.0
    @Published var duration = 0.0
    @Published var playing = false
    @Published var external = false
    @Published var message = "Choose a video, then select Kayle with the AirPlay button."
    @Published var hasItem = false
    private var timer: Any?
    private var statusObserver: NSKeyValueObservation?
    private var routeObserver: NSKeyValueObservation?
    private var itemObserver: NSKeyValueObservation?

    init() {
        player.allowsExternalPlayback = true
        timer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] time in
            guard let self = self else { return }
            self.current = time.seconds.isFinite ? max(0, time.seconds) : 0
            let length = self.player.currentItem?.duration.seconds ?? 0
            self.duration = length.isFinite ? max(0, length) : 0
        }
        statusObserver = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            DispatchQueue.main.async {
                self?.playing = player.timeControlStatus == .playing
                if player.timeControlStatus == .waitingToPlayAtSpecifiedRate { self?.message = "Buffering…" }
                else if player.timeControlStatus == .playing { self?.message = player.isExternalPlaybackActive ? "Playing on AirPlay" : "Playing on iPhone · tap AirPlay to send it to Kayle" }
            }
        }
        routeObserver = player.observe(\.isExternalPlaybackActive, options: [.initial, .new]) { [weak self] player, _ in
            DispatchQueue.main.async {
                self?.external = player.isExternalPlaybackActive
                if self?.hasItem == true { self?.message = player.isExternalPlaybackActive ? "AirPlay connected" : "AirPlay not connected · use the route button" }
            }
        }
    }
    deinit {
        if let timer = timer { player.removeTimeObserver(timer) }
    }
    func load(_ stream: Stream) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { message = "Audio session failed: \(error.localizedDescription)"; return }
        title = stream.title
        current = 0
        duration = 0
        hasItem = true
        message = "Opening video…"
        let item = AVPlayerItem(url: stream.url)
        itemObserver = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                if item.status == .failed {
                    self?.message = "This link could not play. Try the website player’s own AirPlay button or another source."
                }
            }
        }
        player.replaceCurrentItem(with: item)
        player.play()
    }
    func toggle() { if playing { player.pause() } else if hasItem { player.play() } }
    func stop() { player.pause(); player.replaceCurrentItem(with: nil); hasItem = false; current = 0; duration = 0; message = "Stopped." }
    func seek(_ seconds: Double) {
        guard seconds.isFinite, seconds >= 0, duration > 0, seconds < duration,
              let item = player.currentItem, !item.seekableTimeRanges.isEmpty else {
            message = "This stream does not currently support that seek position."
            return
        }
        player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: CMTime(seconds: 0.5, preferredTimescale: 600))
    }
    var canSeek: Bool { duration > 0 && !(player.currentItem?.seekableTimeRanges.isEmpty ?? true) }
}

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let view = AVRoutePickerView()
        view.prioritizesVideoDevices = true
        view.tintColor = .white
        view.activeTintColor = .cyan
        return view
    }
    func updateUIView(_ view: AVRoutePickerView, context: Context) {}
}

struct NativePlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let view = AVPlayerViewController()
        view.player = player
        view.allowsPictureInPicturePlayback = true
        view.showsPlaybackControls = true
        return view
    }
    func updateUIViewController(_ view: AVPlayerViewController, context: Context) { view.player = player }
}
