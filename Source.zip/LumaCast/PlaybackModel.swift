import Foundation
import SwiftUI
import Combine
import GoogleCastDynamic

@MainActor
enum CastBootstrap {
    private static var configured = false
    static func configure() {
        guard !configured else { return }
        configured = true
        let discovery = GCKDiscoveryCriteria(applicationID: kGCKDefaultMediaReceiverApplicationID)
        let options = GCKCastOptions(discoveryCriteria: discovery)
        GCKCastContext.setSharedInstanceWith(options)
        GCKCastContext.sharedInstance().useDefaultExpandedMediaControls = true
    }
}

@MainActor
final class PlaybackModel: NSObject, ObservableObject, GCKSessionManagerListener, GCKRemoteMediaClientListener, GCKRequestDelegate {
    @Published var title = "Nothing playing"
    @Published var current = 0.0
    @Published var duration = 0.0
    @Published var playing = false
    @Published var connected = false
    @Published var deviceName = "Choose your TV"
    @Published var message = "Tap the Cast button and choose Kayle."
    @Published var hasItem = false
    @Published var canSeek = false
    @Published var isLoading = false
    private var pending: Stream?
    private weak var remote: GCKRemoteMediaClient?
    private var timer: Timer?
    private var awaitingURL: String?
    private let manager: GCKSessionManager

    override init() {
        CastBootstrap.configure()
        manager = GCKCastContext.sharedInstance().sessionManager
        super.init()
        manager.add(self)
        if let session = manager.currentCastSession, session.connectionState == .connected { attach(session) }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self = self, self.hasItem, let remote = self.remote else { return }
                let time = remote.approximateStreamPosition()
                if time.isFinite { self.current = max(0, time) }
            }
        }
    }
    deinit { timer?.invalidate() }

    func load(_ stream: Stream) {
        guard MediaRules.httpURL(stream.url.absoluteString) != nil,
              MediaRules.kind(url: stream.url, contentType: MediaRules.mimeType(for: stream)) != nil else {
            message = "Choose a full video file or playlist."
            return
        }
        pending = stream
        title = stream.title
        if !connected || remote == nil {
            message = "Video selected. Tap Cast and choose Kayle to start."
            return
        }
        sendPending()
    }

    private func sendPending() {
        guard let stream = pending, connected, let remote = remote else { return }
        pending = nil
        awaitingURL = stream.url.absoluteString
        title = stream.title
        current = 0; duration = 0; hasItem = false; canSeek = false; playing = false; isLoading = true
        message = "Loading on \(deviceName)…"
        let metadata = GCKMediaMetadata(metadataType: .movie)
        metadata.setString(stream.title, forKey: kGCKMetadataKeyTitle)
        let info = GCKMediaInformationBuilder(contentURL: stream.url)
        info.contentType = MediaRules.mimeType(for: stream)
        info.streamType = .buffered
        info.metadata = metadata
        let request = GCKMediaLoadRequestDataBuilder()
        request.mediaInformation = info.build()
        request.autoplay = true
        remote.loadMedia(with: request.build()).delegate = self
    }

    func toggle() {
        guard connected, hasItem, let remote = remote else { return }
        if playing { remote.pause().delegate = self } else { remote.play().delegate = self }
    }
    func stop() {
        pending = nil
        awaitingURL = nil
        guard connected, let remote = remote else { clearPlayback(); message = "Stopped."; return }
        remote.stop().delegate = self
    }
    func seek(_ seconds: Double) {
        guard connected, hasItem, canSeek, seconds.isFinite, seconds >= 0, seconds < duration, let remote = remote else {
            message = "Choose a time within a seekable video."
            return
        }
        let options = GCKMediaSeekOptions()
        options.interval = seconds
        options.relative = false
        // The default unchanged resume state preserves pause/play while jumping.
        remote.seek(with: options).delegate = self
    }
    func showFullControls() { GCKCastContext.sharedInstance().presentDefaultExpandedMediaControls() }

    private func attach(_ session: GCKCastSession) {
        remote?.remove(self)
        remote = session.remoteMediaClient
        remote?.add(self)
        connected = true
        deviceName = session.device.friendlyName ?? "Cast TV"
        message = "Connected to \(deviceName). Choose a video to cast."
        if pending != nil { sendPending() } else { update(remote?.mediaStatus) }
    }
    private func detach(_ text: String) {
        remote?.remove(self)
        remote = nil
        connected = false
        awaitingURL = nil
        clearPlayback()
        message = text
    }
    private func clearPlayback() {
        current = 0; duration = 0; hasItem = false; playing = false; canSeek = false; isLoading = false
    }
    private func update(_ status: GCKMediaStatus?) {
        guard let status = status else { return }
        if status.playerState == .idle {
            if awaitingURL != nil && status.idleReason != .error { return }
            awaitingURL = nil
            clearPlayback()
            message = status.idleReason == .error ? "The TV could not play this source. Try another full playlist or video file." : "Playback stopped."
            return
        }
        guard let info = status.mediaInformation else { return }
        if let expected = awaitingURL, info.contentID != expected { return }
        awaitingURL = nil
        hasItem = true
        playing = status.playerState == .playing
        isLoading = status.playerState == .buffering || status.playerState == .loading
        let length = info.streamDuration
        duration = length.isFinite ? max(0, length) : 0
        current = status.streamPosition.isFinite ? max(0, status.streamPosition) : 0
        canSeek = duration > 0 && status.isMediaCommandSupported(kGCKMediaCommandSeek)
        title = info.metadata?.string(forKey: kGCKMetadataKeyTitle) ?? title
        if isLoading { message = "Buffering on \(deviceName)…" }
        else { message = playing ? "Playing on \(deviceName)" : "Paused on \(deviceName)" }
    }

    func sessionManager(_ sessionManager: GCKSessionManager, didStart session: GCKSession) {
        if let cast = session as? GCKCastSession { attach(cast) }
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didResumeSession session: GCKSession) {
        if let cast = session as? GCKCastSession { attach(cast) }
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didEnd session: GCKSession, withError error: Error?) {
        pending = nil
        detach(error == nil ? "Disconnected. Tap Cast to reconnect." : "Cast connection ended. Tap Cast to reconnect.")
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didFailToStart session: GCKSession, withError error: Error) {
        pending = nil
        detach("Could not connect to the TV. Check Wi-Fi and allow Local Network access in iPhone Settings.")
    }
    func sessionManager(_ sessionManager: GCKSessionManager, didSuspend session: GCKSession, with reason: GCKConnectionSuspendReason) {
        detach("Cast connection interrupted. Waiting for reconnection…")
    }
    func remoteMediaClient(_ client: GCKRemoteMediaClient, didUpdate mediaStatus: GCKMediaStatus?) { update(mediaStatus) }
    func request(_ request: GCKRequest, didFailWithError error: GCKError) {
        awaitingURL = nil
        isLoading = false
        message = "Cast request failed: \(error.localizedDescription). Try a different source."
    }
}

struct CastButton: UIViewRepresentable {
    func makeUIView(context: Context) -> GCKUICastButton {
        let button = GCKUICastButton(frame: .zero)
        button.tintColor = .cyan
        return button
    }
    func updateUIView(_ button: GCKUICastButton, context: Context) {}
}
