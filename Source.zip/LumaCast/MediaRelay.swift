import Foundation
import Network

struct BrowserRequestContext {
    var referer: URL?
    var userAgent: String
    var cookies: [HTTPCookie]

    func request(_ url: URL, method: String = "GET", range: String? = nil) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 25
        request.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        if let referer {
            request.setValue(referer.absoluteString, forHTTPHeaderField: "Referer")
            if var origin = URLComponents(url: referer, resolvingAgainstBaseURL: false) {
                origin.path = ""; origin.query = nil; origin.fragment = nil
                request.setValue(origin.string, forHTTPHeaderField: "Origin")
            }
        }
        request.setValue(RelayRules.cookieHeader(cookies, url: url), forHTTPHeaderField: "Cookie")
        request.setValue(RelayRules.byteRange(range), forHTTPHeaderField: "Range")
        return request
    }
}

// A bounded, in-memory relay for app-selected media. LAN requests cannot select an upstream URL.
final class MediaRelay: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private final class Scope {
        let id = UUID().uuidString
        let base: URL
        let context: BrowserRequestContext
        var reports = 0
        init(base: URL, context: BrowserRequestContext) { self.base = base; self.context = context }
    }
    private struct Target {
        let url: URL
        let playlist: Bool
        let scope: Scope
        var inline: Data? = nil
    }
    private let lock = NSLock()
    private var targets: [String: Target] = [:]
    private var reverse: [String: String] = [:]
    private var scopes: [String] = []
    private var transfers: [Int: Transfer] = [:]
    private let configuration: URLSessionConfiguration
    var onError: ((String) -> Void)?
    var onEvent: ((String) -> Void)?
    private lazy var session: URLSession = {
        let queue = OperationQueue(); queue.maxConcurrentOperationCount = 1
        return URLSession(configuration: configuration, delegate: self, delegateQueue: queue)
    }()

    init(configuration: URLSessionConfiguration = .ephemeral) {
        self.configuration = configuration
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 1800
        configuration.httpMaximumConnectionsPerHost = 6
        super.init()
    }

    func publish(url: URL, playlist: String?, isHLS: Bool, base: URL, context: BrowserRequestContext) throws -> URL {
        let scope = Scope(base: base, context: context)
        lock.lock()
        scopes.append(scope.id)
        if scopes.count > 4 {
            let expired = scopes.removeFirst()
            targets = targets.filter { $0.value.scope.id != expired }
            reverse = reverse.filter { !$0.key.hasPrefix(expired + "|") }
        }
        lock.unlock()
        guard let mapped = register(url, playlist: isHLS, scope: scope) else { throw Failure.invalidPlaylist }
        if let playlist {
            guard let rewritten = rewrite(playlist, base: context.referer, scope: scope) else { throw Failure.invalidPlaylist }
            lock.lock(); targets[mapped.path]?.inline = Data(rewritten.utf8); lock.unlock()
        }
        return mapped
    }

    private func register(_ url: URL, playlist: Bool, scope: Scope) -> URL? {
        guard MediaRules.httpURL(url.absoluteString) != nil || url.scheme == "blob" else { return nil }
        let key = scope.id + "|" + (playlist ? "hls|" : "media|") + url.absoluteString
        lock.lock(); defer { lock.unlock() }
        if let path = reverse[key] { return URL(string: path, relativeTo: scope.base)?.absoluteURL }
        guard targets.count < 30_000 else { return nil }
        let path = "/relay/" + UUID().uuidString.lowercased() + (playlist ? "/stream.m3u8" : "/media")
        targets[path] = Target(url: url, playlist: playlist, scope: scope)
        reverse[key] = path
        return URL(string: path, relativeTo: scope.base)?.absoluteURL
    }

    private func rewrite(_ text: String, base: URL?, scope: Scope) -> String? {
        RelayRules.rewrite(text, base: base) { self.register($0, playlist: $1, scope: scope) }
    }

    func handle(header: String, connection: NWConnection) -> Bool {
        let lines = header.components(separatedBy: "\r\n")
        let first = lines.first?.split(separator: " ") ?? []
        guard first.count == 3, String(first[1]).hasPrefix("/relay/") else { return false }
        let method = String(first[0]), path = String(first[1])
        lock.lock(); let target = targets[path]; let busy = transfers.count >= 12; lock.unlock()
        guard let target else { reply(connection, status: 404); return true }
        guard ["GET", "HEAD", "OPTIONS"].contains(method) else { reply(connection, status: 405); return true }
        if method == "OPTIONS" { reply(connection, status: 204); return true }
        if let data = target.inline {
            onEvent?("TV requested captured playlist (\(data.count) bytes)")
            reply(connection, status: 200, type: "application/vnd.apple.mpegurl", body: data, head: method == "HEAD")
            return true
        }
        guard !busy else { reply(connection, status: 503); return true }
        let range = lines.dropFirst().first { $0.lowercased().hasPrefix("range:") }.map { String($0.dropFirst(6)).trimmingCharacters(in: .whitespaces) }
        let request = target.scope.context.request(target.url, method: "GET", range: target.playlist ? nil : range)
        let transfer = Transfer(owner: self, target: target, connection: connection, head: method == "HEAD", range: range)
        lock.lock(); transfer.report = target.scope.reports < 6; target.scope.reports += 1; lock.unlock()
        if transfer.report { onEvent?("TV " + method + " requested " + (target.playlist ? "playlist" : "media segment") + " from " + (target.url.host ?? "source")) }
        let task = session.dataTask(with: request); transfer.task = task
        lock.lock(); transfers[task.taskIdentifier] = transfer; lock.unlock()
        connection.stateUpdateHandler = { [weak task] state in if case .cancelled = state { task?.cancel() } }
        task.resume()
        return true
    }

    private func transfer(_ task: URLSessionTask) -> Transfer? { lock.lock(); defer { lock.unlock() }; return transfers[task.taskIdentifier] }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let transfer = transfer(dataTask), let http = response as? HTTPURLResponse else { completionHandler(.cancel); return }
        transfer.response = http
        if transfer.report { onEvent?("Source HTTP \(http.statusCode) · \(http.mimeType ?? "unknown content type")") }
        if !(200...299).contains(http.statusCode) {
            onError?("Media server returned HTTP \(http.statusCode) from \(http.url?.host ?? "source").")
            transfer.finished = true
            reply(transfer.connection, status: http.statusCode); completionHandler(.cancel); return
        }
        transfer.playlist = transfer.playlist || (http.mimeType?.contains("mpegurl") ?? false) || http.url?.pathExtension.lowercased() == "m3u8"
        completionHandler(.allow)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let transfer = transfer(task), let url = request.url, MediaRules.httpURL(url.absoluteString) != nil, transfer.redirects < 8 else { completionHandler(nil); return }
        transfer.redirects += 1
        // Recompute cookies for the destination; never forward another host's credentials.
        completionHandler(transfer.target.scope.context.request(url, method: "GET", range: transfer.target.playlist ? nil : transfer.range))
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) { transfer(dataTask)?.receive(data) }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock(); let transfer = transfers.removeValue(forKey: task.taskIdentifier); lock.unlock()
        transfer?.complete(error)
    }

    private static func headers(status: Int, type: String, length: Int64?, extra: [String: String] = [:]) -> Data {
        var value = "HTTP/1.1 \(status) \(HTTPURLResponse.localizedString(forStatusCode: status))\r\nContent-Type: \(type)\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, HEAD, OPTIONS\r\nAccess-Control-Allow-Headers: Range, Content-Type\r\nAccess-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges\r\nAccess-Control-Allow-Private-Network: true\r\nCache-Control: no-store\r\nConnection: close\r\n"
        if let length { value += "Content-Length: \(length)\r\n" }
        for (key, item) in extra where !item.contains("\r") && !item.contains("\n") { value += "\(key): \(item)\r\n" }
        return Data((value + "\r\n").utf8)
    }
    private func reply(_ connection: NWConnection, status: Int, type: String = "text/plain", body: Data = Data(), head: Bool = false) {
        var data = Self.headers(status: status, type: type, length: Int64(body.count))
        if !head { data.append(body) }
        connection.send(content: data, completion: .contentProcessed { _ in connection.cancel() })
    }
    enum Failure: LocalizedError {
        case invalidPlaylist
        var errorDescription: String? { "This playlist could not be prepared for the TV. Try another server." }
    }

    private final class Transfer: @unchecked Sendable {
        weak var owner: MediaRelay?
        let target: Target
        let connection: NWConnection
        let head: Bool
        let range: String?
        var task: URLSessionDataTask?
        var response: HTTPURLResponse?
        var playlist: Bool
        var buffer = Data()
        var sentHeader = false
        var redirects = 0
        var finished = false
        var report = false
        var totalBytes = 0
        init(owner: MediaRelay, target: Target, connection: NWConnection, head: Bool, range: String?) {
            self.owner = owner; self.target = target; self.connection = connection; self.head = head; self.range = range; self.playlist = target.playlist
        }
        func receive(_ incoming: Data) {
            guard !finished else { return }
            totalBytes += incoming.count
            var data = incoming
            if !sentHeader && !playlist {
                buffer.append(data)
                guard buffer.count >= 385 else { return }
                data = buffer; buffer = Data()
                if String(data: data.prefix(64), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") == true { playlist = true }
            }
            if playlist {
                guard buffer.count + data.count <= 4 * 1024 * 1024 else { task?.cancel(); owner?.onError?("The source playlist exceeds the supported size."); return }
                buffer.append(data); return
            }
            if head {
                // HEAD responses have no body, so a mislabeled upstream HEAD cannot be sniffed.
                // Inspect a small GET prefix, send corrected metadata only, then stop the upstream.
                finished = true
                let metadata = header(prefix: data)
                if report { owner?.onEvent?("Inspected \(totalBytes) bytes for HEAD; sending metadata only") }
                connection.send(content: metadata, completion: .contentProcessed { _ in
                    self.task?.cancel(); self.connection.cancel()
                })
                return
            }
            var payload = Data()
            if !sentHeader { payload.append(header(prefix: data)); sentHeader = true }
            if !head { payload.append(data) }
            task?.suspend()
            connection.send(content: payload, completion: .contentProcessed { [weak self] error in
                if error != nil { self?.task?.cancel() } else { self?.task?.resume() }
            })
        }
        private func header(prefix: Data) -> Data {
            let type = RelayRules.mediaType(prefix: prefix, supplied: response?.mimeType ?? "application/octet-stream")
            if report { owner?.onEvent?("Serving \(type) to TV") }
            var extra: [String: String] = [:]
            for name in ["Content-Range", "Accept-Ranges"] { if let value = response?.value(forHTTPHeaderField: name) { extra[name] = value } }
            let encoded = response?.value(forHTTPHeaderField: "Content-Encoding").map { $0 != "identity" } ?? false
            let count = response?.expectedContentLength ?? -1
            return MediaRelay.headers(status: response?.statusCode ?? 200, type: type, length: !encoded && count >= 0 ? count : nil, extra: extra)
        }
        func complete(_ error: Error?) {
            if finished { return }
            guard let owner else { connection.cancel(); return }
            guard error == nil else {
                if !sentHeader { owner.reply(connection, status: 502) } else { connection.cancel() }
                if (error as NSError?)?.code != NSURLErrorCancelled { owner.onError?("The media connection failed. Reload the page and try again.") }
                return
            }
            if report { owner.onEvent?("Received \(totalBytes) media bytes") }
            if playlist {
                guard let text = String(data: buffer, encoding: .utf8), let rewritten = owner.rewrite(text, base: response?.url ?? target.url, scope: target.scope) else {
                    owner.reply(connection, status: 502); owner.onError?("The source did not return a usable HLS playlist."); return
                }
                owner.reply(connection, status: 200, type: "application/vnd.apple.mpegurl", body: Data(rewritten.utf8), head: head)
            } else {
                guard totalBytes > 0 else {
                    owner.onError?("The media server returned an empty body for a GET request.")
                    owner.reply(connection, status: 502); return
                }
                var end = sentHeader ? Data() : header(prefix: buffer)
                if !sentHeader && !head { end.append(buffer) }
                connection.send(content: end, completion: .contentProcessed { _ in self.connection.cancel() })
            }
        }
    }
}
