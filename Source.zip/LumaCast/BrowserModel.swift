import SwiftUI
import WebKit
import Combine

// The bridge can report URLs only. Web pages cannot invoke native commands.
@MainActor
private final class WeakBridge: NSObject, WKScriptMessageHandler {
    weak var owner: BrowserModel?
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: String], let text = body["url"] else { return }
        let frame = MediaRules.httpURL(body["frameURL"] ?? "") ?? message.frameInfo.request.url
        if body["event"] == "playlist", let raw = body["playlist"], !raw.isEmpty,
           let playlist = HLSPlaylist.normalized(raw, baseURL: MediaRules.httpURL(body["baseURL"] ?? "")) {
            owner?.detectBlob(text, playlist: playlist, title: body["title"] ?? "Web video", frameURL: frame)
            return
        }
        if body["event"] == "exclude" { owner?.exclude(text); return }
        owner?.detect(text, contentType: body["type"] ?? "", title: body["title"] ?? "Web video", frameURL: frame, isMaster: body["role"] == "master")
    }
}

@MainActor
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var isHome = true
    @Published private(set) var pinnedSites: [Bookmark] = []
    @Published var streams: [Stream] = []
    @Published var address = ""
    @Published var title = "Browse"
    @Published var message = "Open a website and tap its video to discover streams."
    @Published var blocking = true
    @Published var loading = false
    @Published var bookmarks: [Bookmark] = []
    let webView: WKWebView
    private let bridge: WeakBridge
    private var ruleList: WKContentRuleList?
    private var generation = 0
    private var excludedURLs: Set<URL> = []

    override init() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsAirPlayForMediaPlayback = false
        config.mediaTypesRequiringUserActionForPlayback = .all
        bridge = WeakBridge()
        if let file = Bundle.main.url(forResource: "DetectMedia", withExtension: "js"),
           let code = try? String(contentsOf: file, encoding: .utf8) {
            config.userContentController.addUserScript(WKUserScript(source: code, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        config.userContentController.add(bridge, name: "stream")
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        bridge.owner = self
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        if let data = UserDefaults.standard.data(forKey: "bookmarks"), let saved = try? JSONDecoder().decode([Bookmark].self, from: data) { bookmarks = saved }
        blocking = UserDefaults.standard.object(forKey: "blocking") as? Bool ?? true
        if let file = Bundle.main.url(forResource: "PinnedSites", withExtension: "json"),
           let data = try? Data(contentsOf: file), let pins = try? JSONDecoder().decode([Bookmark].self, from: data) {
            pinnedSites = pins.filter { MediaRules.httpURL($0.url.absoluteString) != nil }
        }
        compileRules()
    }

    func showStartPage() {
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        isHome = true
        loading = false
        address = ""
        title = "Luma Cast"
    }

    func navigate(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidate = trimmed.contains("://") ? trimmed : "https://" + trimmed
        guard let url = MediaRules.httpURL(candidate) else { message = "Enter an http or https website address."; return }
        isHome = false
        webView.load(URLRequest(url: url))
    }

    func detect(_ text: String, contentType: String, title: String, frameURL: URL? = nil, isMaster: Bool = false) {
        guard let url = MediaRules.httpURL(text), let kind = MediaRules.kind(url: url, contentType: contentType),
              !excludedURLs.contains(url) else { return }
        if let index = streams.firstIndex(where: { $0.url == url }) {
            let old = streams[index]
            streams[index] = Stream(url: url, title: old.title, kind: old.isMasterPlaylist || isMaster ? "HLS" : kind, playlistText: old.playlistText,
                                    isMasterPlaylist: old.isMasterPlaylist || isMaster,
                                    sourcePage: old.sourcePage, embedPage: old.embedPage)
            streams.sort { ($0.isMasterPlaylist ? 0 : 1) < ($1.isMasterPlaylist ? 0 : 1) }
            return
        }
        guard streams.count < 100 else { return }
        let pageTitle = webView.title?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let displayTitle = pageTitle.isEmpty ? title : pageTitle
        streams.append(Stream(url: url, title: String(displayTitle.prefix(200)), kind: kind, isMasterPlaylist: isMaster,
                              sourcePage: webView.url, embedPage: frameURL))
        streams.sort { ($0.isMasterPlaylist ? 0 : $0.kind == "HLS" ? 1 : 2) < ($1.isMasterPlaylist ? 0 : $1.kind == "HLS" ? 1 : 2) }
        message = "Found \(streams.count) video link\(streams.count == 1 ? "" : "s"). Open Videos to choose one."
    }

    func detectBlob(_ text: String, playlist: String, title: String, frameURL: URL?) {
        guard let url = URL(string: text), url.scheme == "blob" || MediaRules.httpURL(text) != nil,
              !excludedURLs.contains(url) else { return }
        let bytes = streams.reduce(0) { $0 + ($1.playlistText?.utf8.count ?? 0) }
        guard bytes + playlist.utf8.count <= 20 * 1024 * 1024 else { return }
        streams.removeAll { $0.url == url }
        guard streams.count < 100 else { return }
        let pageTitle = webView.title?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let master = playlist.contains("#EXT-X-STREAM-INF:")
        streams.insert(Stream(url: url, title: pageTitle.isEmpty ? title : pageTitle, kind: "HLS", playlistText: playlist,
                              isMasterPlaylist: master, sourcePage: webView.url, embedPage: frameURL), at: 0)
        message = "Captured the full playlist in the browser. Keep Luma open while casting."
    }

    func exclude(_ text: String) {
        guard let url = MediaRules.httpURL(text) else { return }
        if excludedURLs.count < 10_000 { excludedURLs.insert(url) }
        streams.removeAll { $0.url == url }
    }

    func scan() { webView.evaluateJavaScript("window.__lumaScan && window.__lumaScan()", completionHandler: nil) }
    func requestContext(for stream: Stream) async -> BrowserRequestContext {
        let cookies = await webView.configuration.websiteDataStore.httpCookieStore.allCookies()
        let agent = (try? await webView.evaluateJavaScript("navigator.userAgent")) as? String
        return BrowserRequestContext(referer: stream.embedPage ?? stream.sourcePage,
                                     userAgent: agent ?? "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Version/16.0 Mobile/15E148 Safari/604.1",
                                     cookies: cookies)
    }
    func saveBookmark() {
        guard let url = webView.url, MediaRules.httpURL(url.absoluteString) != nil else { return }
        bookmarks.removeAll { $0.url == url }
        bookmarks.insert(Bookmark(url: url, title: title), at: 0)
        bookmarks = Array(bookmarks.prefix(100))
        UserDefaults.standard.set(try? JSONEncoder().encode(bookmarks), forKey: "bookmarks")
        message = "Saved this page."
    }
    func toggleBlocking() {
        blocking.toggle()
        generation += 1
        UserDefaults.standard.set(blocking, forKey: "blocking")
        updateRules()
        if !isHome { webView.reload() }
    }
    private func compileRules() {
        guard let file = Bundle.main.url(forResource: "BlockRules", withExtension: "json"),
              let rules = try? String(contentsOf: file, encoding: .utf8) else { return }
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "luma-basic-v1", encodedContentRuleList: rules) { [weak self] list, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.ruleList = list
                self.updateRules()
                if error != nil { self.message = "Ad filters could not load. Popup blocking is still available." }
            }
        }
    }
    private func updateRules() {
        webView.configuration.userContentController.removeAllContentRuleLists()
        if blocking, let list = ruleList { webView.configuration.userContentController.add(list) }
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        loading = true
        streams.removeAll()
        excludedURLs.removeAll()
        generation += 1
        message = "Loading page…"
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard !isHome else { return }
        loading = false
        address = webView.url?.absoluteString ?? ""
        title = webView.title ?? "Web video"
        // Detection can arrive before the main page has its final title.
        for index in streams.indices where streams[index].sourcePage == webView.url {
            let old = streams[index]
            streams[index] = Stream(url: old.url, title: title, kind: old.kind, playlistText: old.playlistText, isMasterPlaylist: old.isMasterPlaylist, sourcePage: old.sourcePage, embedPage: old.embedPage)
        }
        if streams.isEmpty { message = "Tap the page’s video, then check Videos." }
        scan()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { loading = false; message = error.localizedDescription }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { loading = false; message = error.localizedDescription }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url, MediaRules.httpURL(url.absoluteString) != nil else { decisionHandler(.cancel); return }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let url = response.response.url { detect(url.absoluteString, contentType: response.response.mimeType ?? "", title: title) }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // Deny new windows while blocking is on, even for unlisted ad domains.
        if !blocking, let url = action.request.url, MediaRules.httpURL(url.absoluteString) != nil { webView.load(action.request) }
        return nil
    }
}

struct BrowserSurface: UIViewRepresentable {
    let model: BrowserModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ view: WKWebView, context: Context) {}
}
