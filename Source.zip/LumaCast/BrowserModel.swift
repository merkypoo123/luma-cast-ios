import SwiftUI
import WebKit
import Combine

// The bridge can report URLs only. Web pages cannot invoke native commands.
@MainActor
private final class WeakBridge: NSObject, WKScriptMessageHandler {
    weak var owner: BrowserModel?
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: String], let text = body["url"] else { return }
        owner?.detect(text, contentType: body["type"] ?? "", title: body["title"] ?? "Web video")
    }
}

@MainActor
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var streams: [Stream] = []
    @Published var address = ""
    @Published var title = "Browse"
    @Published var message = "Open a website and tap its video to discover streams."
    @Published var blocking = true
    @Published var loading = false
    @Published var bookmarks: [Bookmark] = []
    let webView: WKWebView
    private let bridge: WeakBridge
    private var ruleList: WKContentRuleList?
    private var generation = 0

    override init() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsAirPlayForMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = .all
        bridge = WeakBridge()
        if let file = Bundle.main.url(forResource: "DetectMedia", withExtension: "js"),
           let code = try? String(contentsOf: file, encoding: .utf8) {
            config.userContentController.addUserScript(WKUserScript(source: code, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        config.userContentController.add(bridge, name: "stream")
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        bridge.owner = self
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        if let data = UserDefaults.standard.data(forKey: "bookmarks"), let saved = try? JSONDecoder().decode([Bookmark].self, from: data) { bookmarks = saved }
        blocking = UserDefaults.standard.object(forKey: "blocking") as? Bool ?? true
        compileRules()
    }

    func navigate(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidate = trimmed.contains("://") ? trimmed : "https://" + trimmed
        guard let url = MediaRules.httpURL(candidate) else { message = "Enter an http or https website address."; return }
        webView.load(URLRequest(url: url))
    }

    func detect(_ text: String, contentType: String, title: String) {
        guard let url = MediaRules.httpURL(text), let kind = MediaRules.kind(url: url, contentType: contentType),
              !streams.contains(where: { $0.url == url }), streams.count < 100 else { return }
        streams.append(Stream(url: url, title: String(title.prefix(200)), kind: kind))
        streams.sort { ($0.kind == "HLS" ? 0 : 1) < ($1.kind == "HLS" ? 0 : 1) }
        message = "Found \(streams.count) video link\(streams.count == 1 ? "" : "s"). Open Videos to choose one."
    }

    func scan() { webView.evaluateJavaScript("window.__lumaScan && window.__lumaScan()", completionHandler: nil) }
    func saveBookmark() {
        guard let url = webView.url, MediaRules.httpURL(url.absoluteString) != nil else { return }
        bookmarks.removeAll { $0.url == url }
        bookmarks.insert(Bookmark(url: url, title: title), at: 0)
        bookmarks = Array(bookmarks.prefix(100))
        UserDefaults.standard.set(try? JSONEncoder().encode(bookmarks), forKey: "bookmarks")
        message = "Saved this page."
    }
    func toggleBlocking() {
        blocking.toggle()
        generation += 1
        UserDefaults.standard.set(blocking, forKey: "blocking")
        updateRules()
        webView.reload()
    }
    private func compileRules() {
        guard let file = Bundle.main.url(forResource: "BlockRules", withExtension: "json"),
              let rules = try? String(contentsOf: file, encoding: .utf8) else { return }
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "luma-basic-v1", encodedContentRuleList: rules) { [weak self] list, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.ruleList = list
                self.updateRules()
                if error != nil { self.message = "Ad filters could not load. Popup blocking is still available." }
            }
        }
    }
    private func updateRules() {
        webView.configuration.userContentController.removeAllContentRuleLists()
        if blocking, let list = ruleList { webView.configuration.userContentController.add(list) }
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        loading = true
        streams.removeAll()
        generation += 1
        message = "Loading page…"
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loading = false
        address = webView.url?.absoluteString ?? ""
        title = webView.title ?? "Web video"
        if streams.isEmpty { message = "Tap the page’s video, then check Videos. You can also use its own AirPlay button." }
        scan()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { loading = false; message = error.localizedDescription }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { loading = false; message = error.localizedDescription }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url, MediaRules.httpURL(url.absoluteString) != nil else { decisionHandler(.cancel); return }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let url = response.response.url { detect(url.absoluteString, contentType: response.response.mimeType ?? "", title: title) }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // Deny new windows while blocking is on, even for unlisted ad domains.
        if !blocking, let url = action.request.url, MediaRules.httpURL(url.absoluteString) != nil { webView.load(action.request) }
        return nil
    }
}

struct BrowserSurface: UIViewRepresentable {
    let model: BrowserModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ view: WKWebView, context: Context) {}
}
