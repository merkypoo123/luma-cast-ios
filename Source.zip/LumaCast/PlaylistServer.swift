import Foundation
import Network
import Darwin

final class PlaylistServer: @unchecked Sendable {
    private let queue = DispatchQueue(label: "dev.kayle.lumacast.playlists")
    private var listener: NWListener?
    private var port: UInt16?
    private var waiters: [CheckedContinuation<UInt16, Error>] = []
    private var resources: [String: Data] = [:]
    private var paths: [String] = []

    enum Failure: LocalizedError {
        case wifiUnavailable, stopped
        var errorDescription: String? {
            switch self {
            case .wifiUnavailable: return "Connect the iPhone to the same Wi-Fi as the TV, then retry."
            case .stopped: return "The iPhone playlist server could not start. Retry with Luma open."
            }
        }
    }

    func publish(_ playlist: String) async throws -> URL {
        guard let host = Self.wifiAddress() else { throw Failure.wifiUnavailable }
        let port = try await start()
        try Task.checkCancellation()
        let path = "/" + UUID().uuidString.lowercased() + "/master.m3u8"
        queue.sync {
            resources[path] = Data(playlist.utf8)
            paths.append(path)
            if paths.count > 8 { resources.removeValue(forKey: paths.removeFirst()) }
        }
        return URL(string: "http://\(host):\(port)\(path)")!
    }

    private func start() async throws -> UInt16 {
        try await withCheckedThrowingContinuation { continuation in
            queue.async { [self] in
                if let port { continuation.resume(returning: port); return }
                waiters.append(continuation)
                guard listener == nil else { return }
                do {
                    let server = try NWListener(using: .tcp, on: .any)
                    listener = server
                    server.newConnectionHandler = { [weak self] connection in self?.receive(connection) }
                    server.stateUpdateHandler = { [weak self, weak server] state in
                        guard let self, let server, self.listener === server else { return }
                        switch state {
                        case .ready:
                            guard let value = server.port?.rawValue else { return }
                            self.port = value
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(returning: value) }
                        case .failed(let error):
                            self.port = nil; self.listener = nil
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(throwing: error) }
                            server.cancel()
                        case .cancelled:
                            self.port = nil; self.listener = nil
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(throwing: Failure.stopped) }
                        default: break
                        }
                    }
                    server.start(queue: queue)
                    queue.asyncAfter(deadline: .now() + 8) { [weak self, weak server] in
                        guard let self, let server, self.listener === server, self.port == nil else { return }
                        server.cancel()
                    }
                } catch {
                    let pending = waiters; waiters.removeAll()
                    pending.forEach { $0.resume(throwing: error) }
                }
            }
        }
    }

    private func receive(_ connection: NWConnection) {
        connection.start(queue: queue)
        queue.asyncAfter(deadline: .now() + 8) { connection.cancel() }
        readHeader(connection, bytes: Data())
    }

    private func readHeader(_ connection: NWConnection, bytes: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] chunk, _, complete, error in
            guard let self else { connection.cancel(); return }
            var bytes = bytes
            if let chunk { bytes.append(chunk) }
            guard bytes.count <= 16_384, error == nil else { connection.cancel(); return }
            if let text = String(data: bytes, encoding: .utf8), text.contains("\r\n\r\n") {
                let response = PlaylistHTTP.response(header: text, resources: self.resources)
                connection.send(content: response, completion: .contentProcessed { _ in connection.cancel() })
            } else if complete { connection.cancel() }
            else { self.readHeader(connection, bytes: bytes) }
        }
    }

    private static func wifiAddress() -> String? {
        var first: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&first) == 0 else { return nil }
        defer { freeifaddrs(first) }
        var current = first
        while let entry = current {
            defer { current = entry.pointee.ifa_next }
            guard let address = entry.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET),
                  ["en0", "en1"].contains(String(cString: entry.pointee.ifa_name)) else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(address, socklen_t(address.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: host)
            }
        }
        return nil
    }

    deinit { listener?.cancel() }
}
