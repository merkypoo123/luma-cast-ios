import Foundation
import Network
import Darwin

final class PlaylistServer: @unchecked Sendable {
    private let queue = DispatchQueue(label: "dev.kayle.lumacast.playlists")
    private var listener: NWListener?
    private var port: UInt16?
    private var waiters: [CheckedContinuation<UInt16, Error>] = []
    private var resources: [String: Data] = [:]
    private var paths: [String] = []
    private var introResources: [String: Data] = [:]
    private var introPath: String?
    private let relay = MediaRelay()
    var onError: ((String) -> Void)? { get { relay.onError } set { relay.onError = newValue } }
    var onEvent: ((String) -> Void)? { get { relay.onEvent } set { relay.onEvent = newValue } }

    func relay(_ stream: Stream, context: BrowserRequestContext) async throws -> URL {
        guard let host = Self.wifiAddress() else { throw Failure.wifiUnavailable }
        let port = try await start()
        try Task.checkCancellation()
        let base = URL(string: "http://\(host):\(port)")!
        return try relay.publish(url: stream.url, playlist: stream.playlistText, isHLS: stream.kind == "HLS", base: base, context: context)
    }

    func intro() async throws -> URL {
        guard let host = Self.wifiAddress(), let file = Bundle.main.url(forResource: "TVIntro", withExtension: "mp4") else { throw Failure.stopped }
        let port = try await start()
        try Task.checkCancellation()
        let path: String = try queue.sync {
            if let introPath { return introPath }
            let data = try Data(contentsOf: file, options: .mappedIfSafe)
            guard !data.isEmpty, data.count <= 16 * 1024 * 1024 else { throw Failure.stopped }
            let path = "/intro/" + UUID().uuidString.lowercased() + "/intro.mp4"
            introResources[path] = data; introPath = path
            return path
        }
        return URL(string: "http://\(host):\(port)\(path)")!
    }

    enum Failure: LocalizedError {
        case wifiUnavailable, stopped
        var errorDescription: String? {
            switch self {
            case .wifiUnavailable: return "Connect the iPhone to the same Wi-Fi as the TV, then retry."
            case .stopped: return "The iPhone playlist server could not start. Retry with Luma open."
            }
        }
    }

    func publish(_ playlist: String) async throws -> URL {
        guard let host = Self.wifiAddress() else { throw Failure.wifiUnavailable }
        let port = try await start()
        try Task.checkCancellation()
        let path = "/" + UUID().uuidString.lowercased() + "/master.m3u8"
        queue.sync {
            resources[path] = Data(playlist.utf8)
            paths.append(path)
            if paths.count > 8 { resources.removeValue(forKey: paths.removeFirst()) }
        }
        return URL(string: "http://\(host):\(port)\(path)")!
    }

    private func start() async throws -> UInt16 {
        try await withCheckedThrowingContinuation { continuation in
            queue.async { [self] in
                if let port { continuation.resume(returning: port); return }
                waiters.append(continuation)
                guard listener == nil else { return }
                do {
                    let server = try NWListener(using: .tcp, on: .any)
                    listener = server
                    server.newConnectionHandler = { [weak self] connection in self?.receive(connection) }
                    server.stateUpdateHandler = { [weak self, weak server] state in
                        guard let self, let server, self.listener === server else { return }
                        switch state {
                        case .ready:
                            guard let value = server.port?.rawValue else { return }
                            self.port = value
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(returning: value) }
                        case .failed(let error):
                            self.port = nil; self.listener = nil
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(throwing: error) }
                            server.cancel()
                        case .cancelled:
                            self.port = nil; self.listener = nil
                            let pending = self.waiters; self.waiters.removeAll()
                            pending.forEach { $0.resume(throwing: Failure.stopped) }
                        default: break
                        }
                    }
                    server.start(queue: queue)
                    queue.asyncAfter(deadline: .now() + 8) { [weak self, weak server] in
                        guard let self, let server, self.listener === server, self.port == nil else { return }
                        server.cancel()
                    }
                } catch {
                    let pending = waiters; waiters.removeAll()
                    pending.forEach { $0.resume(throwing: error) }
                }
            }
        }
    }

    private func receive(_ connection: NWConnection) {
        connection.start(queue: queue)
        let timeout = DispatchWorkItem { connection.cancel() }
        queue.asyncAfter(deadline: .now() + 8, execute: timeout)
        readHeader(connection, bytes: Data(), timeout: timeout)
    }

    private func readHeader(_ connection: NWConnection, bytes: Data, timeout: DispatchWorkItem) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] chunk, _, complete, error in
            guard let self else { connection.cancel(); return }
            var bytes = bytes
            if let chunk { bytes.append(chunk) }
            guard bytes.count <= 16_384, error == nil else { connection.cancel(); return }
            if let text = String(data: bytes, encoding: .utf8), text.contains("\r\n\r\n") {
                timeout.cancel()
                if self.relay.handle(header: text, connection: connection) { return }
                let isIntro = text.components(separatedBy: "\r\n").first?.split(separator: " ").dropFirst().first?.hasPrefix("/intro/") ?? false
                let response = isIntro ? IntroHTTP.response(header: text, resources: self.introResources) : PlaylistHTTP.response(header: text, resources: self.resources)
                connection.send(content: response, completion: .contentProcessed { _ in connection.cancel() })
            } else if complete { connection.cancel() }
            else { self.readHeader(connection, bytes: bytes, timeout: timeout) }
        }
    }

    private static func wifiAddress() -> String? {
        var first: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&first) == 0 else { return nil }
        defer { freeifaddrs(first) }
        var current = first
        while let entry = current {
            defer { current = entry.pointee.ifa_next }
            guard let address = entry.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET),
                  ["en0", "en1"].contains(String(cString: entry.pointee.ifa_name)) else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(address, socklen_t(address.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: host)
            }
        }
        return nil
    }

    deinit { listener?.cancel() }
}
