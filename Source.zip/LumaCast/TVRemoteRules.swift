import Foundation

enum TVShortcut: String, CaseIterable, Identifiable {
    case netflix, stan, hbo, prime
    var id: String { rawValue }
    var name: String {
        switch self { case .netflix: return "Netflix"; case .stan: return "Stan"; case .hbo: return "HBO Max"; case .prime: return "Prime Video" }
    }
    var asset: String { "Remote-" + rawValue }
    var appLink: String? {
        switch self { case .netflix: return "https://www.netflix.com/title/"; case .prime: return "https://app.primevideo.com/"; default: return nil }
    }
    // Kayle's configured home shelf: YouTube, HBO Max, Prime Video, Stan, Netflix.
    var shelfPosition: Int? { self == .hbo ? 1 : self == .stan ? 3 : nil }
}

struct TVTextPress: Equatable { let code: UInt; let shift: Bool }
enum TVRemoteRules {
    static func host(_ raw: String) -> String? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value.count <= 253, value.range(of: "^[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]$", options: .regularExpression) != nil else { return nil }
        if value.allSatisfy({ $0.isNumber || $0 == "." }) {
            let bits = value.split(separator:".",omittingEmptySubsequences:false)
            guard bits.count == 4, bits.allSatisfy({ Int($0).map { (0...255).contains($0) } == true }) else { return nil }
        }
        return value
    }
    static func pairingCode(_ raw: String) -> String? {
        let code = raw.trimmingCharacters(in:.whitespacesAndNewlines).uppercased()
        return code.range(of:"^[0-9A-F]{6}$",options:.regularExpression) == nil ? nil : code
    }
    static func text(_ text: String) -> [TVTextPress]? {
        guard text.count <= 200 else { return nil }
        var presses: [TVTextPress] = []
        let punctuation: [UInt32: UInt] = [32:62,44:55,46:56,45:69,61:70,91:71,93:72,92:73,59:74,39:75,47:76,64:77,43:81,10:66]
        for scalar in text.unicodeScalars {
            let n = scalar.value
            if (65...90).contains(n) { presses.append(TVTextPress(code:UInt(n-65+29),shift:true)) }
            else if (97...122).contains(n) { presses.append(TVTextPress(code:UInt(n-97+29),shift:false)) }
            else if (48...57).contains(n) { presses.append(TVTextPress(code:UInt(n-48+7),shift:false)) }
            else if let key = punctuation[n] { presses.append(TVTextPress(code:key,shift:false)) }
            else { return nil }
        }
        return presses
    }
}
