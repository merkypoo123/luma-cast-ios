import Foundation

struct Stream: Identifiable, Hashable {
    var id: String { url.absoluteString }
    let url: URL
    let title: String
    let kind: String
}

struct Bookmark: Identifiable, Codable {
    var id: String { url.absoluteString }
    let url: URL
    let title: String
}

enum MediaRules {
    static func httpURL(_ text: String) -> URL? {
        guard text.count <= 16_384, let url = URL(string: text),
              let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme),
              url.host != nil, url.user == nil, url.password == nil else { return nil }
        return url
    }

    static func kind(url: URL, contentType: String = "") -> String? {
        let ext = url.pathExtension.lowercased()
        let name = url.lastPathComponent.lowercased()
        let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        if ["ts", "m4s", "cmfa", "cmfv", "aac"].contains(ext) { return nil }
        if name.range(of: "^(init|chunk|segment|frag)[-_0-9.]", options: .regularExpression) != nil { return nil }
        if query.contains(where: { $0.name.lowercased() == "seg" && Int($0.value ?? "") != nil }) { return nil }
        let type = contentType.lowercased()
        if ext == "m3u8" || type.contains("mpegurl") { return "HLS" }
        if ext == "mpd" || type.contains("dash+xml") { return "DASH" }
        if ext == "webm" || type.contains("video/webm") { return "WebM" }
        if ext == "mp4" || type.contains("video/mp4") { return "MP4" }
        if ext == "mov" || type.contains("video/quicktime") { return "MOV" }
        if ext == "mp3" || type.contains("audio/mpeg") { return "Audio" }
        if ext == "m4a" || type.contains("audio/mp4") { return "Audio" }
        return nil
    }

    static func mimeType(for stream: Stream) -> String {
        switch stream.kind {
        case "HLS": return "application/x-mpegURL"
        case "DASH": return "application/dash+xml"
        case "WebM": return "video/webm"
        case "MOV": return "video/quicktime"
        case "Audio": return stream.url.pathExtension.lowercased() == "mp3" ? "audio/mpeg" : "audio/mp4"
        default: return "video/mp4"
        }
    }

    static func seconds(_ text: String) -> Double? {
        let parts = text.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ":", omittingEmptySubsequences: false)
        guard (1...3).contains(parts.count) else { return nil }
        var result = 0.0
        for (index, part) in parts.enumerated() {
            guard !part.isEmpty, part.allSatisfy({ $0.isNumber }), let n = Double(part), n.isFinite,
                  index == 0 || n < 60 else { return nil }
            result = result * 60 + n
        }
        return result.isFinite ? result : nil
    }

    static func clock(_ time: Double) -> String {
        guard time.isFinite, time >= 0, time < Double(Int.max / 2) else { return "0:00" }
        let n = Int(time)
        if n >= 3600 { return String(format: "%d:%02d:%02d", n / 3600, (n / 60) % 60, n % 60) }
        return String(format: "%d:%02d", n / 60, n % 60)
    }
}
