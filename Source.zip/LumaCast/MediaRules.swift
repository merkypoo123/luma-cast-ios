import Foundation

struct Stream: Identifiable, Hashable {
    var id: String { url.absoluteString }
    let url: URL
    let title: String
    let kind: String
    var playlistText: String? = nil
    var hlsAudioFMP4 = false
    var hlsVideoFMP4 = false
    var isMasterPlaylist = false
    var sourcePage: URL? = nil
    var embedPage: URL? = nil
    var sourceHost: String { sourcePage?.host ?? url.host ?? "Unknown website" }
    var fileLabel: String { url.lastPathComponent.isEmpty ? kind + " stream" : url.lastPathComponent }
}

struct Bookmark: Identifiable, Codable {
    var id: String { url.absoluteString }
    let url: URL
    let title: String
}

enum MediaRules {
    static func httpURL(_ text: String) -> URL? {
        guard text.count <= 16_384, let url = URL(string: text),
              let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme),
              url.host != nil, url.user == nil, url.password == nil else { return nil }
        return url
    }

    static func kind(url: URL, contentType: String = "") -> String? {
        let ext = url.pathExtension.lowercased()
        let name = url.lastPathComponent.lowercased()
        let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        if ["ts", "m4s", "cmfa", "cmfv", "aac"].contains(ext) { return nil }
        if name.range(of: "^(init|chunk|segment|frag)[-_0-9.]", options: .regularExpression) != nil { return nil }
        if query.contains(where: { $0.name.lowercased() == "seg" && Int($0.value ?? "") != nil }) { return nil }
        let type = contentType.lowercased()
        if ext == "m3u8" || type.contains("mpegurl") { return "HLS" }
        if ext == "mpd" || type.contains("dash+xml") { return "DASH" }
        if ext == "webm" || type.contains("video/webm") { return "WebM" }
        if ext == "mp4" || type.contains("video/mp4") { return "MP4" }
        if ext == "mov" || type.contains("video/quicktime") { return "MOV" }
        if ext == "mp3" || type.contains("audio/mpeg") { return "Audio" }
        if ext == "m4a" || type.contains("audio/mp4") { return "Audio" }
        return nil
    }

    static func mimeType(for stream: Stream) -> String {
        switch stream.kind {
        case "HLS": return "application/x-mpegURL"
        case "DASH": return "application/dash+xml"
        case "WebM": return "video/webm"
        case "MOV": return "video/quicktime"
        case "Audio": return stream.url.pathExtension.lowercased() == "mp3" ? "audio/mpeg" : "audio/mp4"
        default: return "video/mp4"
        }
    }

    static func matchesCastMedia(expected: String, contentID: String?, contentURL: URL?) -> Bool {
        contentID == expected || contentURL?.absoluteString == expected
    }

    static func seconds(_ text: String) -> Double? {
        let parts = text.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ":", omittingEmptySubsequences: false)
        guard (1...3).contains(parts.count) else { return nil }
        var result = 0.0
        for (index, part) in parts.enumerated() {
            guard !part.isEmpty, part.allSatisfy({ $0.isNumber }), let n = Double(part), n.isFinite,
                  index == 0 || n < 60 else { return nil }
            result = result * 60 + n
        }
        return result.isFinite ? result : nil
    }

    static func clock(_ time: Double) -> String {
        guard time.isFinite, time >= 0, time < Double(Int.max / 2) else { return "0:00" }
        let n = Int(time)
        if n >= 3600 { return String(format: "%d:%02d:%02d", n / 3600, (n / 60) % 60, n % 60) }
        return String(format: "%d:%02d", n / 60, n % 60)
    }
}


enum HLSPlaylist {
    static func childPlaylists(_ text: String) -> (audio: URL?, video: URL?) {
        var audio: URL?, video: URL?
        let uri = try! NSRegularExpression(pattern: "URI=\"([^\"]+)\"")
        for line in text.components(separatedBy: .newlines) {
            if audio == nil, line.hasPrefix("#EXT-X-MEDIA:"), line.contains("TYPE=AUDIO"),
               let match = uri.firstMatch(in: line, range: NSRange(line.startIndex..., in: line)),
               let range = Range(match.range(at: 1), in: line) { audio = MediaRules.httpURL(String(line[range])) }
            if video == nil, !line.hasPrefix("#"), let url = MediaRules.httpURL(line) { video = url }
        }
        return (audio, video)
    }

    static func normalized(_ text: String, baseURL: URL?) -> String? {
        guard text.utf8.count <= 4 * 1024 * 1024,
              text.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U"),
              text.contains("#EXT-X-STREAM-INF:") || text.contains("#EXT-X-TARGETDURATION:") else { return nil }
        let uri = try! NSRegularExpression(pattern: "URI=\"([^\"]+)\"")
        func resolve(_ value: String) -> String? {
            guard let url = URL(string: value, relativeTo: baseURL)?.absoluteURL,
                  MediaRules.httpURL(url.absoluteString) != nil else { return nil }
            return url.absoluteString
        }
        var lines: [String] = []
        for raw in text.components(separatedBy: .newlines) {
            var line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if !line.isEmpty && !line.hasPrefix("#") {
                guard let absolute = resolve(line) else { return nil }
                line = absolute
            } else {
                let matches = uri.matches(in: line, range: NSRange(line.startIndex..., in: line))
                for match in matches.reversed() {
                    guard let range = Range(match.range(at: 1), in: line), let absolute = resolve(String(line[range])) else { return nil }
                    line.replaceSubrange(range, with: absolute)
                }
            }
            lines.append(line)
        }
        return lines.joined(separator: "\n")
    }
}

// Each target is registered by the app, never accepted as a URL query from the LAN.
enum RelayRules {
    static func rewrite(_ text: String, base: URL?, register: (URL, Bool) -> URL?) -> String? {
        guard let normalized = HLSPlaylist.normalized(text, baseURL: base) else { return nil }
        let master = normalized.contains("#EXT-X-STREAM-INF:")
        let uri = try! NSRegularExpression(pattern: "URI=\"([^\"]+)\"")
        var lines: [String] = []
        for raw in normalized.components(separatedBy: .newlines) {
            var line = raw
            if !line.isEmpty && !line.hasPrefix("#") {
                guard let url = MediaRules.httpURL(line), let mapped = register(url, master) else { return nil }
                line = mapped.absoluteString
            } else {
                for match in uri.matches(in: line, range: NSRange(line.startIndex..., in: line)).reversed() {
                    guard let range = Range(match.range(at: 1), in: line),
                          let url = MediaRules.httpURL(String(line[range])),
                          let mapped = register(url, line.hasPrefix("#EXT-X-MEDIA:") || line.hasPrefix("#EXT-X-I-FRAME-STREAM-INF:")) else { return nil }
                    line.replaceSubrange(range, with: mapped.absoluteString)
                }
            }
            lines.append(line)
        }
        return lines.joined(separator: "\n")
    }

    static func cookieHeader(_ cookies: [HTTPCookie], url: URL, now: Date = Date()) -> String? {
        guard let host = url.host?.lowercased() else { return nil }
        let matching = cookies.filter { cookie in
            let domain = cookie.domain.lowercased()
            let domainOK = domain.hasPrefix(".") ? (host == String(domain.dropFirst()) || host.hasSuffix(domain)) : host == domain
            let path = cookie.path.isEmpty ? "/" : cookie.path
            let pathOK = url.path == path || (url.path.hasPrefix(path) && (path.hasSuffix("/") || url.path.dropFirst(path.count).hasPrefix("/")))
            return domainOK && pathOK && (!cookie.isSecure || url.scheme == "https") && (cookie.expiresDate.map { $0 > now } ?? true)
        }.sorted { $0.path.count > $1.path.count }
        return matching.isEmpty ? nil : HTTPCookie.requestHeaderFields(with: matching)["Cookie"]
    }

    static func mediaType(prefix: Data, supplied: String) -> String {
        let bytes = [UInt8](prefix.prefix(385))
        if bytes.count > 188, bytes[0] == 0x47, bytes[188] == 0x47 { return "video/mp2t" }
        if bytes.count >= 8, ["ftyp", "moof", "styp"].contains(String(bytes: bytes[4..<8], encoding: .ascii) ?? "") { return "video/mp4" }
        return supplied
    }

    static func byteRange(_ value: String?) -> String? {
        guard let value, value.count <= 100,
              value.range(of: "^bytes=(?:[0-9]+-[0-9]*|-[0-9]+)$", options: .regularExpression) != nil else { return nil }
        return value
    }
}

// A narrow HTTP surface: only random, app-created playlist paths are served.
enum PlaylistHTTP {
    static func response(header: String, resources: [String: Data]) -> Data {
        let first = header.components(separatedBy: "\r\n").first?.split(separator: " ") ?? []
        let method = first.first.map(String.init) ?? ""
        let path = first.count > 1 ? String(first[1]) : ""
        let status: String
        let body: Data
        if method == "OPTIONS" { status = "204 No Content"; body = Data() }
        else if method != "GET" && method != "HEAD" { status = "405 Method Not Allowed"; body = Data() }
        else if let data = resources[path] { status = "200 OK"; body = data }
        else { status = "404 Not Found"; body = Data() }
        let head = "HTTP/1.1 \(status)\r\nContent-Type: application/vnd.apple.mpegurl\r\nContent-Length: \(body.count)\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, HEAD, OPTIONS\r\nAccess-Control-Allow-Headers: Range, Content-Type\r\nAccess-Control-Allow-Private-Network: true\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
        var result = Data(head.utf8)
        if method != "HEAD" { result.append(body) }
        return result
    }
}
