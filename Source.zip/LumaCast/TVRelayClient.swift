import Foundation
import Security
import Combine

private final class RelayPinnedTrust: NSObject, URLSessionDelegate, @unchecked Sendable {
    let host: String
    let certificate: Data
    init(host: String, certificate: Data) { self.host = host; self.certificate = certificate }
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              challenge.protectionSpace.host == host,
              let trust = challenge.protectionSpace.serverTrust,
              let leaf = SecTrustGetCertificateAtIndex(trust, 0),
              SecCertificateCopyData(leaf) as Data == certificate else {
            completionHandler(.cancelAuthenticationChallenge, nil); return
        }
        completionHandler(.useCredential, URLCredential(trust: trust))
    }
}

@MainActor final class TVRelayClient: ObservableObject {
    static let shared = TVRelayClient()
    @Published var host = UserDefaults.standard.string(forKey: "tvRelayHost") ?? "192.168.0.13"
    @Published var enabled = UserDefaults.standard.object(forKey: "tvRelayEnabled") as? Bool ?? true {
        didSet { UserDefaults.standard.set(enabled, forKey: "tvRelayEnabled") }
    }
    @Published var status = "Open Kayle TV Relay on the TV, show a new code, then pair here."
    @Published var paired = false
    @Published var busy = false
    private var token: String? {
        guard let data = TVRemoteSecrets.pin("tv-relay:" + host) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    init() { paired = token != nil }
    func pair(_ code: String) {
        guard code.count == 6, code.allSatisfy(\.isNumber) else { status = "Enter the six digits shown by Kayle TV Relay."; return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let response = try await call("pair", object: ["code": code], authenticated: false)
                guard let value = response["token"] as? String, value.count == 64 else { throw Failure.invalid }
                try TVRemoteSecrets.savePin(Data(value.utf8), host: "tv-relay:" + host)
                UserDefaults.standard.set(host, forKey: "tvRelayHost")
                paired = true; status = "TV relay paired. New casts can continue without the phone."
            } catch { status = error.localizedDescription }
        }
    }
    func publish(_ stream: Stream, context: BrowserRequestContext) async throws -> URL {
        var object: [String: Any] = ["url": stream.url.absoluteString, "kind": stream.kind, "userAgent": context.userAgent,
            "referer": context.referer?.absoluteString ?? ""]
        if let text = stream.playlistText { object["playlist"] = text }
        var destinations = [stream.url]
        if let text = stream.playlistText {
            _ = RelayRules.rewrite(text, base: stream.embedPage ?? stream.sourcePage) { url, _ in destinations.append(url); return url }
        }
        let relevant = context.cookies.filter { cookie in
            destinations.contains { url in
                guard let host = url.host?.lowercased() else { return false }
                let domain = cookie.domain.lowercased()
                return domain.hasPrefix(".") ? host == String(domain.dropFirst()) || host.hasSuffix(domain) : host == domain
            }
        }
        object["cookies"] = relevant.map { cookie -> [String: Any] in
            var item: [String: Any] = ["name": cookie.name, "value": cookie.value, "domain": cookie.domain, "path": cookie.path, "secure": cookie.isSecure]
            if let date = cookie.expiresDate { item["expires"] = date.timeIntervalSince1970 }
            return item
        }
        let result = try await call("session", object: object)
        guard let text = result["url"] as? String, let url = MediaRules.httpURL(text), url.host == host, url.port == 8890, url.path.hasPrefix("/media/") else { throw Failure.invalid }
        status = "TV relay is serving this cast. The iPhone can leave the foreground."
        return url
    }
    private func call(_ path: String, object: [String: Any], authenticated: Bool = true) async throws -> [String: Any] {
        guard let value = TVRemoteRules.host(host), value == host,
              let certURL = Bundle.main.url(forResource: "KayleRelayCertificate", withExtension: "der"),
              let certificate = try? Data(contentsOf: certURL),
              let url = URL(string: "https://\(host):8889/\(path)") else { throw Failure.invalid }
        var request = URLRequest(url: url); request.httpMethod = "POST"; request.timeoutInterval = 45
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if authenticated { guard let token else { throw Failure.pair }; request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        request.httpBody = try JSONSerialization.data(withJSONObject: object)
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil; config.urlCredentialStorage = nil; config.urlCache = nil
        let delegate = RelayPinnedTrust(host: host, certificate: certificate)
        let session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        do {
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw Failure.pair }
            guard let result = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw Failure.invalid }
            return result
        } catch let failure as Failure { throw failure }
        catch { CastDiagnostics.event("TV relay control error=" + CastDiagnostics.error(error)); throw Failure.connection }
    }
    enum Failure: LocalizedError {
        case invalid, pair, connection
        var errorDescription: String? {
            switch self {
            case .invalid: return "TV relay identity or response did not match. Reopen the companion and check its address."
            case .pair: return "TV relay pairing is required, or its code expired. Show a new code on the TV and pair again."
            case .connection: return "Cannot reach the verified TV relay. Open Kayle TV Relay on the TV, then retry."
            }
        }
    }
}
