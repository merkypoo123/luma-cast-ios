import SwiftUI

@main
@MainActor
struct LumaCastApp: App {
    var body: some Scene {
        WindowGroup { ContentView().preferredColorScheme(.dark).tint(.cyan) }
    }
}
