import SwiftUI

@main
@MainActor
struct LumaCastApp: App {
    init() { CastBootstrap.configure() }
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
