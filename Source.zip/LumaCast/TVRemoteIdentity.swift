import Foundation
import Security

struct TVRemoteIdentity: @unchecked Sendable {
    let identity: SecIdentity
    let publicKey: SecKey
    static let label = "dev.kayle.lumacast.remote.identity.v1"

    static func loadOrCreate() throws -> TVRemoteIdentity {
        if let existing = lookupIdentity() { return try wrap(existing) }
        let tag = Data(label.utf8)
        let query: [String: Any] = [kSecClass as String:kSecClassKey,kSecAttrApplicationTag as String:tag,kSecAttrKeyType as String:kSecAttrKeyTypeRSA,kSecReturnRef as String:true]
        var found: CFTypeRef?
        let existing = SecItemCopyMatching(query as CFDictionary, &found)
        let key: SecKey
        if existing == errSecSuccess, let found, CFGetTypeID(found) == SecKeyGetTypeID() { key = found as! SecKey }
        else {
            let attrs: [String: Any] = [kSecAttrKeyType as String:kSecAttrKeyTypeRSA,kSecAttrKeySizeInBits as String:2048,
                kSecPrivateKeyAttrs as String:[kSecAttrIsPermanent as String:true,kSecAttrApplicationTag as String:tag,kSecAttrLabel as String:label,kSecAttrAccessible as String:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]]
            var error: Unmanaged<CFError>?
            guard let generated = SecKeyCreateRandomKey(attrs as CFDictionary, &error) else { throw Failure.key }
            key = generated
        }
        let bytes = try certificate(for: key)
        guard let cert = SecCertificateCreateWithData(nil, bytes as CFData) else { throw Failure.certificate }
        let added = SecItemAdd([kSecClass as String:kSecClassCertificate,kSecValueRef as String:cert,kSecAttrLabel as String:label,kSecAttrAccessible as String:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly] as CFDictionary, nil)
        guard added == errSecSuccess || added == errSecDuplicateItem, let identity = lookupIdentity() else { throw Failure.keychain }
        return try wrap(identity)
    }
    private static func lookupIdentity() -> SecIdentity? {
        var result: CFTypeRef?
        let query: [String: Any] = [kSecClass as String:kSecClassIdentity,kSecAttrLabel as String:label,kSecReturnRef as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let result, CFGetTypeID(result) == SecIdentityGetTypeID() else { return nil }
        return result as! SecIdentity
    }
    private static func wrap(_ identity: SecIdentity) throws -> TVRemoteIdentity {
        var key: SecKey?
        guard SecIdentityCopyPrivateKey(identity, &key) == errSecSuccess, let key, let publicKey = SecKeyCopyPublicKey(key) else { throw Failure.key }
        return TVRemoteIdentity(identity: identity, publicKey: publicKey)
    }
    static func certificate(for key: SecKey, now: Date = Date()) throws -> Data {
        guard let publicKey = SecKeyCopyPublicKey(key), let publicBytes = SecKeyCopyExternalRepresentation(publicKey, nil) as Data? else { throw Failure.key }
        let signatureAlgorithm = Data([0x30,0x0d,0x06,0x09,0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x0b,0x05,0x00])
        let rsaAlgorithm = Data([0x30,0x0d,0x06,0x09,0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x01,0x05,0x00])
        let commonName = der(0x30, der(0x31, der(0x30, Data([0x06,0x03,0x55,0x04,0x03]) + der(0x0c, Data("Luma Cast iPhone".utf8)))))
        let formatter = DateFormatter(); formatter.locale = Locale(identifier:"en_US_POSIX"); formatter.timeZone = TimeZone(secondsFromGMT:0); formatter.dateFormat = "yyyyMMddHHmmss'Z'"
        let validity = der(0x30, der(0x18, Data(formatter.string(from:now.addingTimeInterval(-86400)).utf8)) + der(0x18, Data(formatter.string(from:now.addingTimeInterval(10*365*86400)).utf8)))
        var serial = [UInt8](repeating:0,count:16)
        guard SecRandomCopyBytes(kSecRandomDefault, serial.count, &serial) == errSecSuccess else { throw Failure.key }
        serial[0] = 1
        let spki = der(0x30, rsaAlgorithm + der(0x03, Data([0]) + publicBytes))
        let tbs = der(0x30, der(0xa0, der(0x02, Data([2]))) + der(0x02, Data(serial)) + signatureAlgorithm + commonName + validity + commonName + spki)
        var error: Unmanaged<CFError>?
        guard let signature = SecKeyCreateSignature(key, .rsaSignatureMessagePKCS1v15SHA256, tbs as CFData, &error) as Data? else { throw Failure.certificate }
        return der(0x30, tbs + signatureAlgorithm + der(0x03, Data([0]) + signature))
    }
    private static func der(_ tag: UInt8, _ body: Data) -> Data {
        var header = Data([tag])
        if body.count < 128 { header.append(UInt8(body.count)) }
        else {
            var n = body.count, bytes: [UInt8] = []
            while n > 0 { bytes.insert(UInt8(n & 255),at:0); n >>= 8 }
            header.append(0x80 | UInt8(bytes.count)); header.append(contentsOf:bytes)
        }
        return header + body
    }
    enum Failure: LocalizedError {
        case key, certificate, keychain
        var errorDescription: String? { "The iPhone could not prepare its TV pairing credentials. Close and reopen the app, then retry." }
    }
}

enum TVRemoteSecrets {
    static func pin(_ host: String) -> Data? {
        var result: CFTypeRef?
        let query: [String: Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"dev.kayle.lumacast.remote",kSecAttrAccount as String:host,kSecReturnData as String:true]
        guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess else { return nil }
        return result as? Data
    }
    static func savePin(_ value: Data, host: String) throws {
        let query: [String: Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"dev.kayle.lumacast.remote",kSecAttrAccount as String:host]
        let status = SecItemUpdate(query as CFDictionary,[kSecValueData as String:value] as CFDictionary)
        if status == errSecItemNotFound {
            var add = query; add[kSecValueData as String] = value; add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            guard SecItemAdd(add as CFDictionary,nil) == errSecSuccess else { throw TVRemoteIdentity.Failure.keychain }
        } else if status != errSecSuccess { throw TVRemoteIdentity.Failure.keychain }
    }
}
