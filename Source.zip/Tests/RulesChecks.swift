import Foundation

@main
struct RulesChecks {
    static func main() {
        precondition(MediaRules.httpURL("file:///tmp/a.mp4") == nil)
        precondition(MediaRules.httpURL("https://user:secret@example.com/a.mp4") == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/video.mp4?seg=2")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/chunk001.mp4")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/stream?token=abc")!, contentType: "application/vnd.apple.mpegurl") == "HLS")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/master.m3u8?token=abc")!) == "HLS")
        precondition(MediaRules.seconds("1:23:45") == 5025)
        precondition(MediaRules.seconds("23:15") == 1395)
        precondition(MediaRules.seconds("1:99") == nil)
        precondition(MediaRules.seconds("-5") == nil)
        precondition(MediaRules.seconds(":10") == nil)
        precondition(MediaRules.clock(5025) == "1:23:45")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/master.mpd")!) == "DASH")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/video.webm")!) == "WebM")
        let hls = Stream(url: URL(string: "https://example.com/master.m3u8?token=abc")!, title: "Test", kind: "HLS")
        precondition(MediaRules.mimeType(for: hls) == "application/x-mpegURL")
        precondition(hls.url.query == "token=abc")
        let expected = "https://example.com/movie.mp4?token=keep"
        precondition(MediaRules.matchesCastMedia(expected: expected, contentID: nil, contentURL: URL(string: expected)))
        precondition(MediaRules.matchesCastMedia(expected: expected, contentID: expected, contentURL: nil))
        precondition(!MediaRules.matchesCastMedia(expected: expected, contentID: "another-video", contentURL: nil))
        let sourced = Stream(url: hls.url, title: "Movie on Doraby", kind: "HLS", sourcePage: URL(string: "https://doraby.com/watch/123"), embedPage: URL(string: "https://player.example/embed"))
        precondition(sourced.sourceHost == "doraby.com")
        precondition(sourced.fileLabel == "master.m3u8")
        let manifest = "#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"aud\",URI=\"audio.m3u8?token=keep\"\n#EXT-X-STREAM-INF:BANDWIDTH=1000,AUDIO=\"aud\"\nvideo.m3u8?token=keep\n"
        let normalized = HLSPlaylist.normalized(manifest, baseURL: URL(string: "https://cdn.test/watch/master.m3u8"))!
        precondition(normalized.contains("URI=\"https://cdn.test/watch/audio.m3u8?token=keep\""))
        precondition(normalized.contains("https://cdn.test/watch/video.m3u8?token=keep"))
        precondition(HLSPlaylist.normalized("not a playlist", baseURL: nil) == nil)
        precondition(HLSPlaylist.normalized("#EXTM3U\n#EXT-X-TARGETDURATION:6\nfile:///private/data\n", baseURL: nil) == nil)
        let children = HLSPlaylist.childPlaylists(normalized)
        precondition(children.audio?.absoluteString == "https://cdn.test/watch/audio.m3u8?token=keep")
        precondition(children.video?.absoluteString == "https://cdn.test/watch/video.m3u8?token=keep")
        let body = Data(normalized.utf8)
        let response = PlaylistHTTP.response(header: "GET /random/master.m3u8 HTTP/1.1\r\nHost: phone\r\n\r\n", resources: ["/random/master.m3u8": body])
        let responseText = String(data: response, encoding: .utf8)!
        precondition(responseText.hasPrefix("HTTP/1.1 200"))
        precondition(responseText.contains("Access-Control-Allow-Origin: *"))
        precondition(responseText.hasSuffix(normalized))
        let head = PlaylistHTTP.response(header: "HEAD /random/master.m3u8 HTTP/1.1\r\n\r\n", resources: ["/random/master.m3u8": body])
        precondition(!String(data: head, encoding: .utf8)!.contains("#EXTM3U"))
        let missing = PlaylistHTTP.response(header: "GET /etc/passwd HTTP/1.1\r\n\r\n", resources: [:])
        precondition(String(data: missing, encoding: .utf8)!.hasPrefix("HTTP/1.1 404"))
        print("PASS native URL filtering, Cast content types and seek-time checks")
    }
}
