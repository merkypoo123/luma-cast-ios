import Foundation

@main
struct RulesChecks {
    static func main() {
        precondition(MediaRules.httpURL("file:///tmp/a.mp4") == nil)
        precondition(MediaRules.httpURL("https://user:secret@example.com/a.mp4") == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/video.mp4?seg=2")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/chunk001.mp4")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/stream?token=abc")!, contentType: "application/vnd.apple.mpegurl") == "HLS")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/master.m3u8?token=abc")!) == "HLS")
        precondition(MediaRules.seconds("1:23:45") == 5025)
        precondition(MediaRules.seconds("23:15") == 1395)
        precondition(MediaRules.seconds("1:99") == nil)
        precondition(MediaRules.seconds("-5") == nil)
        precondition(MediaRules.seconds(":10") == nil)
        precondition(MediaRules.clock(5025) == "1:23:45")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/master.mpd")!) == "DASH")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/video.webm")!) == "WebM")
        let hls = Stream(url: URL(string: "https://example.com/master.m3u8?token=abc")!, title: "Test", kind: "HLS")
        precondition(MediaRules.mimeType(for: hls) == "application/x-mpegURL")
        precondition(hls.url.query == "token=abc")
        let expected = "https://example.com/movie.mp4?token=keep"
        precondition(MediaRules.matchesCastMedia(expected: expected, contentID: nil, contentURL: URL(string: expected)))
        precondition(MediaRules.matchesCastMedia(expected: expected, contentID: expected, contentURL: nil))
        precondition(!MediaRules.matchesCastMedia(expected: expected, contentID: "another-video", contentURL: nil))
        let sourced = Stream(url: hls.url, title: "Movie on Doraby", kind: "HLS", sourcePage: URL(string: "https://doraby.com/watch/123"), embedPage: URL(string: "https://player.example/embed"))
        precondition(sourced.sourceHost == "doraby.com")
        precondition(sourced.fileLabel == "master.m3u8")
        print("PASS native URL filtering, Cast content types and seek-time checks")
    }
}
