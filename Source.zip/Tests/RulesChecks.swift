import Foundation

@main
struct RulesChecks {
    static func main() {
        precondition(MediaRules.httpURL("file:///tmp/a.mp4") == nil)
        precondition(MediaRules.httpURL("https://user:secret@example.com/a.mp4") == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/video.mp4?seg=2")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/chunk001.mp4")!) == nil)
        precondition(MediaRules.kind(url: URL(string: "https://example.com/stream?token=abc")!, contentType: "application/vnd.apple.mpegurl") == "HLS")
        precondition(MediaRules.kind(url: URL(string: "https://example.com/master.m3u8?token=abc")!) == "HLS")
        precondition(MediaRules.seconds("1:23:45") == 5025)
        precondition(MediaRules.seconds("23:15") == 1395)
        precondition(MediaRules.seconds("1:99") == nil)
        precondition(MediaRules.seconds("-5") == nil)
        precondition(MediaRules.seconds(":10") == nil)
        precondition(MediaRules.clock(5025) == "1:23:45")
        print("PASS native URL filtering and seek-time checks")
    }
}
