import Foundation
import Network

final class FixtureProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "cdn.fixture" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard let url = request.url else { return }
        let authorized = request.value(forHTTPHeaderField: "User-Agent") == "FixtureBrowser" && request.value(forHTTPHeaderField: "Referer") == "https://player.fixture/embed" && request.value(forHTTPHeaderField: "Cookie")?.contains("session=secret") == true
        var status = authorized ? 200 : 403
        var headers = ["Content-Type": "text/html"]
        var data = Data()
        if authorized {
            switch url.path {
            case "/master.m3u8":
                data = Data("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nquality.m3u8?token=keep\n".utf8)
                headers["Content-Type"] = "application/vnd.apple.mpegurl"
            case "/quality.m3u8":
                precondition(url.query == "token=keep")
                data = Data("#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\nsegment.ts?token=keep\n#EXT-X-ENDLIST\n".utf8)
                headers["Content-Type"] = "application/vnd.apple.mpegurl"
            case "/segment.ts":
                precondition(url.query == "token=keep")
                data = Data(repeating: 0, count: 188 * 6); data[0] = 0x47; data[188] = 0x47
            case "/empty.html":
                data = Data()
            case "/movie.mp4":
                data = Data("0123456789".utf8)
                if request.value(forHTTPHeaderField: "Range") == "bytes=2-5" { status = 206; data = Data(data[2...5]); headers["Content-Range"] = "bytes 2-5/10" }
                headers["Content-Type"] = "video/mp4"
                headers["Accept-Ranges"] = "bytes"
            default: status = 404
            }
        }
        headers["Content-Length"] = String(data.count)
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!, cacheStoragePolicy: .notAllowed)
        if request.httpMethod != "HEAD", !data.isEmpty {
            // Exercise fragmented delivery, including content sniffing across tiny chunks.
            client?.urlProtocol(self, didLoad: Data(data.prefix(1)))
            client?.urlProtocol(self, didLoad: Data(data.dropFirst(1)))
        }
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main struct RelayChecks {
    static func main() async throws {
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [FixtureProtocol.self]
        let relay = MediaRelay(configuration: config)
        let listener = try NWListener(using: .tcp, on: .any)
        let queue = DispatchQueue(label: "relay.fixture")
        listener.newConnectionHandler = { connection in
            connection.start(queue: queue)
            func receive(_ existing: Data) {
                connection.receive(minimumIncompleteLength: 1, maximumLength: 16384) { chunk, _, done, error in
                    var all = existing; if let chunk { all.append(chunk) }
                    if let text = String(data: all, encoding: .utf8), text.contains("\r\n\r\n") {
                        if !relay.handle(header: text, connection: connection) { connection.cancel() }
                    } else if done || error != nil || all.count > 16384 { connection.cancel() }
                    else { receive(all) }
                }
            }
            receive(Data())
        }
        let port: UInt16 = try await withCheckedThrowingContinuation { continuation in
            listener.stateUpdateHandler = { state in
                if case .ready = state { continuation.resume(returning: listener.port!.rawValue) }
                if case .failed(let error) = state { continuation.resume(throwing: error) }
            }
            listener.start(queue: queue)
        }
        defer { listener.cancel() }
        let base = URL(string: "http://127.0.0.1:\(port)")!
        let cookie = HTTPCookie(properties: [.domain: "cdn.fixture", .path: "/", .name: "session", .value: "secret", .secure: "TRUE"])!
        let context = BrowserRequestContext(referer: URL(string: "https://player.fixture/embed"), userAgent: "FixtureBrowser", cookies: [cookie])
        let root = try relay.publish(url: URL(string: "https://cdn.fixture/master.m3u8")!, playlist: nil, isHLS: true, base: base, context: context)
        let (data, response) = try await URLSession.shared.data(from: root)
        precondition((response as! HTTPURLResponse).statusCode == 200)
        let master = String(data: data, encoding: .utf8)!
        precondition(!master.contains("token=keep"))
        let child = HLSPlaylist.childPlaylists(master).video!
        let (variant, _) = try await URLSession.shared.data(from: child)
        let segment = HLSPlaylist.childPlaylists(String(data: variant, encoding: .utf8)!).video!
        var segmentHead = URLRequest(url: segment); segmentHead.httpMethod = "HEAD"
        let (headBytes, headResponse) = try await URLSession.shared.data(for: segmentHead)
        precondition(headBytes.isEmpty, "HEAD must not return movie bytes")
        precondition(headResponse.mimeType == "video/mp2t", "A segment mislabeled text/html must still be identified correctly for HEAD")
        precondition(headResponse.expectedContentLength == 1128, "HEAD must preserve actual segment length")
        let (ts, tsResponse) = try await URLSession.shared.data(from: segment)
        precondition(ts.count == 1128 && ts[0] == 0x47)
        precondition(tsResponse.mimeType == "video/mp2t")
        let file = try relay.publish(url: URL(string: "https://cdn.fixture/movie.mp4")!, playlist: nil, isHLS: false, base: base, context: context)
        var range = URLRequest(url: file); range.setValue("bytes=2-5", forHTTPHeaderField: "Range")
        let (partial, partResponse) = try await URLSession.shared.data(for: range)
        precondition((partResponse as! HTTPURLResponse).statusCode == 206 && String(data: partial, encoding: .utf8) == "2345")
        precondition((partResponse as! HTTPURLResponse).value(forHTTPHeaderField: "Content-Range") == "bytes 2-5/10")
        for (method, status) in [("HEAD",200),("OPTIONS",204),("POST",405)] {
            var request = URLRequest(url: file); request.httpMethod = method
            let (body, result) = try await URLSession.shared.data(for: request)
            precondition((result as! HTTPURLResponse).statusCode == status && body.isEmpty)
        }
        let empty = try relay.publish(url: URL(string: "https://cdn.fixture/empty.html")!, playlist: nil, isHLS: false, base: base, context: context)
        let (_, emptyResponse) = try await URLSession.shared.data(from: empty)
        precondition((emptyResponse as! HTTPURLResponse).statusCode == 502)
        let (_, missing) = try await URLSession.shared.data(from: URL(string: "/relay/unknown", relativeTo: base)!)
        precondition((missing as! HTTPURLResponse).statusCode == 404)
        print("PASS HEAD probe regression, empty GET rejection and native relay: HLS recursion, browser headers/cookies, split media sniffing, byte ranges, HEAD/OPTIONS and unknown routes")
    }
}
