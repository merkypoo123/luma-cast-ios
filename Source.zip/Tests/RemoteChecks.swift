import Foundation
import Security

@main struct RemoteChecks {
    static func main() throws {
        precondition(TVRemoteRules.host("192.168.0.13") == "192.168.0.13")
        precondition(TVRemoteRules.host("300.168.0.13") == nil)
        precondition(TVRemoteRules.host("https://example.com") == nil)
        precondition(TVRemoteRules.pairingCode(" a1b2c3 ") == "A1B2C3")
        precondition(TVRemoteRules.pairingCode("ZZ1111") == nil)
        precondition(TVRemoteRules.text("Az 1") == [TVTextPress(code:29,shift:true),TVTextPress(code:54,shift:false),TVTextPress(code:62,shift:false),TVTextPress(code:8,shift:false)])
        precondition(TVRemoteRules.text("a😀") == nil)
        precondition(TVShortcut.stan.shelfPosition == 3 && TVShortcut.hbo.shelfPosition == 1)
        precondition(TVShortcut.netflix.appLink == "https://www.netflix.com/title/")
        let key = SecKeyCreateRandomKey([kSecAttrKeyType as String:kSecAttrKeyTypeRSA,kSecAttrKeySizeInBits as String:2048] as CFDictionary,nil)!
        let der = try TVRemoteIdentity.certificate(for:key)
        guard let certificate = SecCertificateCreateWithData(nil,der as CFData), let parsed = SecCertificateCopyKey(certificate), let expected = SecKeyCopyPublicKey(key) else { fatalError("Generated certificate is not valid X.509") }
        precondition(SecKeyCopyExternalRepresentation(parsed,nil) as Data? == SecKeyCopyExternalRepresentation(expected,nil) as Data?)
        precondition((SecCertificateCopySubjectSummary(certificate) as String?) == "Luma Cast iPhone")
        let stored = try TVRemoteIdentity.loadOrCreate()
        let restored = try TVRemoteIdentity.loadOrCreate()
        precondition(SecKeyCopyExternalRepresentation(stored.publicKey,nil) as Data? == SecKeyCopyExternalRepresentation(restored.publicKey,nil) as Data?)
        precondition(SecKeyCopyExternalRepresentation(stored.publicKey,nil) != nil)
        print("PASS remote validation, keyboard keys, shortcuts, X.509 creation and persistent Keychain identity reload")
    }
}
