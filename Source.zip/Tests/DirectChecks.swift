import Foundation

final class DirectFixture: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "direct.fixture" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let url = request.url!
        precondition(request.value(forHTTPHeaderField: "Cookie") == nil)
        precondition(request.value(forHTTPHeaderField: "Referer") == nil)
        var status = 200
        var headers = ["Content-Type":"video/mp4", "Access-Control-Allow-Origin":"*"]
        var body = Data([0,0,0,24,102,116,121,112] + Array(repeating:0,count:1016))
        switch url.path {
        case "/public.m3u8", "/protected.m3u8":
            headers["Content-Type"] = "application/vnd.apple.mpegurl"
            let child = url.path == "/protected.m3u8" ? "private.m3u8" : "video.m3u8"
            body = Data(("#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"aud\",URI=\"audio.m3u8\"\n#EXT-X-STREAM-INF:BANDWIDTH=10000,AUDIO=\"aud\"\n" + child + "\n").utf8)
        case "/video.m3u8", "/audio.m3u8", "/private.m3u8":
            headers["Content-Type"] = "application/vnd.apple.mpegurl"
            let media = url.path == "/private.m3u8" ? "private.mp4" : "public.mp4"
            body = Data(("#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\n" + media + "\n#EXT-X-ENDLIST\n").utf8)
        case "/private.mp4": status = 403; body = Data()
        case "/nocors.mp4": headers.removeValue(forKey:"Access-Control-Allow-Origin")
        case "/fake.mp4": headers["Content-Type"] = "text/html"; body = Data("<html>blocked</html>".utf8)
        default: break
        }
        client?.urlProtocol(self,didReceive:HTTPURLResponse(url:url,statusCode:status,httpVersion:"HTTP/1.1",headerFields:headers)!,cacheStoragePolicy:.notAllowed)
        client?.urlProtocol(self,didLoad:body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
@main struct DirectChecks {
    static func main() async throws {
        func check(_ path: String, kind: String = "MP4", inline: String? = nil) async throws -> Bool {
            let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [DirectFixture.self]
            return try await DirectMediaProbe(configuration:config).evaluate(Stream(url:URL(string:"https://direct.fixture" + path)!,title:"Fixture",kind:kind,playlistText:inline)).direct
        }
        let plain = try await check("/public.mp4")
        let hls = try await check("/public.m3u8",kind:"HLS")
        let protected = try await check("/protected.m3u8",kind:"HLS")
        let nocors = try await check("/nocors.mp4")
        let fake = try await check("/fake.mp4")
        let captured = try await check("/public.m3u8",kind:"HLS",inline:"#EXTM3U")
        precondition(plain && hls && !protected && !nocors && !fake && !captured)
        print("PASS credential-free direct MP4/HLS with linked audio; protected descendants, missing CORS, HTML and captured playlists retain relay")
    }
}
