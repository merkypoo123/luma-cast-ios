const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');

test('WebKit bridge reports complete video URLs and content types, excluding fragments and non-web schemes', async () => {
  const sent = [], listeners = {}, responseListeners = [];
  const nodes = [
    {src: 'https://video.test/master.m3u8?token=keep'},
    {src: '/movie.mp4'},
    {src: 'https://video.test/master.mpd'},
    {src: 'https://video.test/video.webm'},
    {src: 'https://video.test/segment001.mp4'},
    {src: 'https://video.test/file.mp4?seg=44'},
    {src: 'blob:https://page.test/id'},
    {src: 'https://video.test/chunk.m4s'},
    {src: 'https://video.test/part.ts'},
    {src: 'https://user:password@video.test/private.mp4'},
    {src: 'file:///private/video.mp4'}
  ];
  class XHR { addEventListener(type, fn) { responseListeners.push(fn); } send() {} }
  const response = {url: 'https://video.test/playlist?token=abc', headers: {get: () => 'application/vnd.apple.mpegurl'}};
  const window = {webkit: {messageHandlers: {stream: {postMessage: body => sent.push(body)}}}, fetch: async () => response};
  const context = {window, document: {baseURI: 'https://page.test/watch', title: 'A movie', querySelectorAll: () => nodes, addEventListener: (event, fn) => { listeners[event] = fn; }, documentElement: {}}, performance: {getEntriesByType: () => []}, XMLHttpRequest: XHR, URL: class extends URL {}, Set, PerformanceObserver: class { observe() {} }, MutationObserver: class { observe() {} }, setTimeout};
  vm.runInNewContext(fs.readFileSync('LumaCast/Resources/DetectMedia.js', 'utf8'), context);
  listeners.DOMContentLoaded();
  window.__lumaScan();
  assert.deepEqual(sent.map(x => x.url), ['https://video.test/master.m3u8?token=keep', 'https://page.test/movie.mp4', 'https://video.test/master.mpd', 'https://video.test/video.webm']);
  assert.equal(await window.fetch('test'), response, 'fetch response remains unchanged');
  assert.equal(sent[4].url, response.url);
  const xhr = new XHR(); xhr.responseURL = 'https://video.test/new-stream'; xhr.getResponseHeader = () => 'video/mp4'; xhr.send(); responseListeners[0]();
  assert.equal(sent[5].url, xhr.responseURL);
  assert.equal(sent[0].title, 'A movie');
});
const makeHarness = (responses, nodes = []) => {
  const sent = [], listeners = {};
  class XHR { addEventListener() {} send() {} }
  const window = {webkit: {messageHandlers: {stream: {postMessage: x => sent.push(x)}}}, fetch: async url => responses.get(url)};
  const context = {window, document: {baseURI: 'https://page.test/watch', title: 'A movie', querySelectorAll: () => nodes, addEventListener: (event, fn) => { listeners[event] = fn; }, documentElement: {}}, performance: {getEntriesByType: () => []}, XMLHttpRequest: XHR, URL: class extends URL {}, Set, TextDecoder, PerformanceObserver: class { observe() {} }, MutationObserver: class { observe() {} }, setTimeout};
  vm.runInNewContext(fs.readFileSync('LumaCast/Resources/DetectMedia.js', 'utf8'), context);
  return {window, sent};
};
const playlistResponse = (url, body, type = 'application/vnd.apple.mpegurl') => {
  const response = new Response(body, {headers: {'Content-Type': type}});
  Object.defineProperty(response, 'url', {value: url});
  return response;
};
const waitForInspection = async () => { for (let i=0; i<20; i++) await new Promise(resolve => setImmediate(resolve)); };

test('master playlists keep audio linked and replace video-only child playlists, including opaque endpoints', async () => {
  const base = 'https://cdn.test/path/master?token=master';
  const body = '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="English, stereo",URI="audio?token=a"\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,AUDIO="audio"\nvideo?token=v\n';
  const responses = new Map([[base, playlistResponse(base, body, 'video/mp4')]]);
  const {window, sent} = makeHarness(responses);
  const response = await window.fetch(base);
  assert.equal(response, responses.get(base), 'website receives its original response');
  await waitForInspection();
  assert.equal(await response.text(), body, 'inspection does not consume the player response');
  assert.deepEqual(sent.filter(x => x.event === 'exclude').map(x => x.url).sort(), ['https://cdn.test/path/audio?token=a','https://cdn.test/path/video?token=v']);
  assert.equal(sent.find(x => x.event === 'playlist').role, 'master');
  assert.equal(sent.find(x => x.event === 'playlist').type, 'application/vnd.apple.mpegurl', 'playlist content overrides a misleading server MIME type');
});

test('opaque init files and segments are removed even if discovered before their parent HLS playlist', async () => {
  const init = 'https://cdn.test/api?d=init&v=1', seg = 'https://cdn.test/api?d=part&v=1', manifest = 'https://cdn.test/hls/variant';
  const body = '#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXT-X-MAP:URI="../api?d=init&v=1"\n#EXTINF:6,\n../api?d=part&v=1\n#EXT-X-ENDLIST\n';
  const responses = new Map([[init, playlistResponse(init, 'binary MP4 init', 'video/mp4')], [manifest, playlistResponse(manifest, body)], [seg, playlistResponse(seg, 'binary MP4 segment', 'video/mp4')]]);
  const {window, sent} = makeHarness(responses);
  await window.fetch(init); await waitForInspection();
  assert(sent.some(x => x.url === init && !x.event), 'simulates a fragment discovered before its playlist');
  await window.fetch(manifest); await waitForInspection();
  assert(sent.some(x => x.url === init && x.event === 'exclude'));
  assert(sent.some(x => x.url === seg && x.event === 'exclude'));
  const count = sent.length;
  await window.fetch(seg); await waitForInspection();
  assert.equal(sent.length, count, 'known fragments cannot reappear in the video list');
  assert.equal(sent.find(x => x.event === 'playlist').role, 'media');
});

test('browser-created HLS master is captured with both video and audio while preserving createObjectURL', async () => {
  const sent = [];
  class XHR { addEventListener() {} send() {} }
  class LocalURL extends URL {}
  LocalURL.createObjectURL = () => 'blob:https://page.test/full-playlist';
  const window = {webkit: {messageHandlers: {stream: {postMessage: x => sent.push(x)}}}};
  const context = {window, document: {baseURI:'https://page.test/player/',title:'Street Fighter',querySelectorAll:()=>[],addEventListener(){}},performance:{getEntriesByType:()=>[]},XMLHttpRequest:XHR,URL:LocalURL,Set,TextDecoder,PerformanceObserver:class{observe(){}},MutationObserver:class{observe(){}},setTimeout};
  vm.runInNewContext(fs.readFileSync('LumaCast/Resources/DetectMedia.js','utf8'),context);
  const text = '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",URI="https://cdn.test/audio?token=keep"\n#EXT-X-STREAM-INF:BANDWIDTH=1000,AUDIO="aud"\nhttps://cdn.test/video?token=keep\n';
  const blob = new Blob([text],{type:'application/vnd.apple.mpegurl'});
  assert.equal(LocalURL.createObjectURL(blob),'blob:https://page.test/full-playlist');
  await waitForInspection();
  const master=sent.find(x=>x.event==='playlist');
  assert.equal(master.url,'blob:https://page.test/full-playlist');
  assert.equal(master.playlist,text);
  assert.equal(master.role,'master');
  assert.equal(master.baseURL,'https://page.test/player/');
  assert(sent.some(x=>x.event==='exclude'&&x.url==='https://cdn.test/audio?token=keep'));
  assert(sent.some(x=>x.event==='exclude'&&x.url==='https://cdn.test/video?token=keep'));
  const count=sent.length;
  LocalURL.createObjectURL({addSourceBuffer() {}});
  await waitForInspection();
  assert.equal(sent.length,count,'MediaSource blobs are not fabricated as playable playlists');
});


test('native Safari video URLs are inspected and their complete master is retained', async () => {
  const url='https://cdn.test/master.m3u8?token=keep';
  const body='#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="a",URI="audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=1000,AUDIO="a"\nvideo.m3u8\n';
  const {window,sent}=makeHarness(new Map([[url,playlistResponse(url,body)]]),[{src:url,type:'application/vnd.apple.mpegurl'}]);
  // Browser-native HLS never calls the instrumented window.fetch itself.
  window.__lumaScan(); await waitForInspection();
  const master=sent.find(x=>x.event==='playlist');
  assert.equal(master.role,'master');assert.equal(master.playlist,body);
  assert.equal(master.frameURL,'https://page.test/watch');
  assert(sent.some(x=>x.event==='exclude'&&x.url==='https://cdn.test/video.m3u8'));
  const count=sent.length;window.__lumaScan();await waitForInspection();assert.equal(sent.length,count);
});

test('large VOD playlists beyond the previous 512KB cap retain their segment exclusions', async () => {
  const url='https://cdn.test/large.m3u8';
  const body='#EXTM3U\n#EXT-X-TARGETDURATION:6\n'+Array.from({length:900},(_,i)=>'#EXTINF:6,\nhttps://cdn.test/'+('x'.repeat(650))+'/page-'+i+'.html\n').join('')+'#EXT-X-ENDLIST\n';
  const {window,sent}=makeHarness(new Map([[url,playlistResponse(url,body)]]));
  await window.fetch(url);await waitForInspection();
  assert.equal(sent.find(x=>x.event==='playlist').playlist,body);
  assert.equal(sent.filter(x=>x.event==='exclude').length,900);
});
