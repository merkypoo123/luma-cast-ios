const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');

test('WebKit bridge reports complete video URLs and content types, excluding fragments and non-web schemes', async () => {
  const sent = [], listeners = {}, responseListeners = [];
  const nodes = [
    {src: 'https://video.test/master.m3u8?token=keep'},
    {src: '/movie.mp4'},
    {src: 'https://video.test/master.mpd'},
    {src: 'https://video.test/video.webm'},
    {src: 'https://video.test/segment001.mp4'},
    {src: 'https://video.test/file.mp4?seg=44'},
    {src: 'blob:https://page.test/id'},
    {src: 'https://video.test/chunk.m4s'},
    {src: 'https://video.test/part.ts'},
    {src: 'https://user:password@video.test/private.mp4'},
    {src: 'file:///private/video.mp4'}
  ];
  class XHR { addEventListener(type, fn) { responseListeners.push(fn); } send() {} }
  const response = {url: 'https://video.test/playlist?token=abc', headers: {get: () => 'application/vnd.apple.mpegurl'}};
  const window = {webkit: {messageHandlers: {stream: {postMessage: body => sent.push(body)}}}, fetch: async () => response};
  const context = {window, document: {baseURI: 'https://page.test/watch', title: 'A movie', querySelectorAll: () => nodes, addEventListener: (event, fn) => { listeners[event] = fn; }, documentElement: {}}, performance: {getEntriesByType: () => []}, XMLHttpRequest: XHR, URL, Set, PerformanceObserver: class { observe() {} }, MutationObserver: class { observe() {} }, setTimeout};
  vm.runInNewContext(fs.readFileSync('LumaCast/Resources/DetectMedia.js', 'utf8'), context);
  listeners.DOMContentLoaded();
  window.__lumaScan();
  assert.deepEqual(sent.map(x => x.url), ['https://video.test/master.m3u8?token=keep', 'https://page.test/movie.mp4', 'https://video.test/master.mpd', 'https://video.test/video.webm']);
  assert.equal(await window.fetch('test'), response, 'fetch response remains unchanged');
  assert.equal(sent[4].url, response.url);
  const xhr = new XHR(); xhr.responseURL = 'https://video.test/new-stream'; xhr.getResponseHeader = () => 'video/mp4'; xhr.send(); responseListeners[0]();
  assert.equal(sent[5].url, xhr.responseURL);
  assert.equal(sent[0].title, 'A movie');
});
